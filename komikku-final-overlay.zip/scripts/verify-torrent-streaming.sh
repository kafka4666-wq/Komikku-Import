#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MANAGER="$ROOT/app/src/main/java/eu/kanade/tachiyomi/torrent/TorrentStreamManager.kt"
WORKER="$ROOT/app/src/main/java/exh/ui/torrent/TorrentImportWorker.kt"
FETCHER="$ROOT/app/src/main/java/eu/kanade/tachiyomi/data/coil/MangaCoverFetcher.kt"

test -s "$MANAGER"
test -s "$WORKER"
test -s "$FETCHER"

python3 - "$MANAGER" "$WORKER" "$FETCHER" <<'PY'
from __future__ import annotations

import pathlib
import struct
import sys
import tempfile
import zipfile
import zlib

manager = pathlib.Path(sys.argv[1]).read_text()
worker = pathlib.Path(sys.argv[2]).read_text()
fetcher = pathlib.Path(sys.argv[3]).read_text()

required_manager_markers = (
    "Semaphore(1)",
    "TEMPORARY_PIECE_BUDGET_BYTES = 64L * 1024L * 1024L",
    "REQUEST_DEADLINE_MILLIS = 4_500L",
    "remove(active.handle, remove_flags_t.from_int(1))",
    "active.catalog.saveDirectory.deleteRecursively()",
    "private suspend fun requestRange",
)
for marker in required_manager_markers:
    assert marker in manager, f"missing storage safeguard: {marker}"

for forbidden in (
    "prefetchCovers(",
    "waitForFileComplete(",
    "filePriority(book.fileIndex, Priority.TOP_PRIORITY)",
    "writeCoverAtomically(",
    "coverWarm",
):
    assert forbidden not in manager, f"forbidden Torrent manager behavior present: {forbidden}"

assert "prefetchCovers(" not in worker, "import worker must not prefetch all Torrent covers"
assert "manager.importLink(link)" in worker, "Torrent metadata import path is missing"

torrent_loader = fetcher.split("private suspend fun torrentCoverLoader", 1)[1].split("private suspend fun httpLoader", 1)[0]
assert "persistentFile" not in torrent_loader, "Torrent cover bytes must not be written to the persistent cover cache"
assert "bytes.inputStream().source().buffer()" in torrent_loader, "Torrent cover must be delivered from request memory"

all_books = manager.split("fun allBooks():", 1)[1].split("fun findBook", 1)[0]
for forbidden in ("ensureSession", "startSelectiveSession", "readCover", "requestRange"):
    assert forbidden not in all_books, f"source-tab browse started Torrent work: {forbidden}"

with tempfile.TemporaryDirectory() as directory:
    archive = pathlib.Path(directory) / "fixture.cbz"
    expected = {
        "cover.jpg": b"\xff\xd8cover-bytes\xff\xd9",
        "001.png": b"\x89PNG\r\n\x1a\npage-one",
    }
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as out:
        for name, data in expected.items():
            out.writestr(name, data)

    raw = archive.read_bytes()
    tail = raw[-min(len(raw), 65557):]
    eocd = tail.rfind(b"PK\x05\x06")
    assert eocd >= 0, "EOCD was not found inside the allowed trailing scan"
    entries, directory_size, directory_offset = struct.unpack_from("<HII", tail, eocd + 10)
    assert entries == len(expected), "fixture central-directory entry count mismatch"
    assert directory_size > 0 and directory_offset > 0, "fixture directory location is invalid"

    position = directory_offset
    extracted = {}
    for _ in range(entries):
        assert raw[position:position + 4] == b"PK\x01\x02", "central-directory signature mismatch"
        flags, compression = struct.unpack_from("<HH", raw, position + 8)
        compressed_size, uncompressed_size = struct.unpack_from("<II", raw, position + 20)
        name_len, extra_len, comment_len = struct.unpack_from("<HHH", raw, position + 28)
        local_offset = struct.unpack_from("<I", raw, position + 42)[0]
        name_start = position + 46
        name = raw[name_start:name_start + name_len].decode("utf-8")
        local_name_len, local_extra_len = struct.unpack_from("<HH", raw, local_offset + 26)
        assert raw[local_offset:local_offset + 4] == b"PK\x03\x04", "local-header signature mismatch"
        payload_start = local_offset + 30 + local_name_len + local_extra_len
        payload = raw[payload_start:payload_start + compressed_size]
        if compression == zipfile.ZIP_DEFLATED:
            payload = zlib.decompress(payload, -zlib.MAX_WBITS)
        assert len(payload) == uncompressed_size, "range extraction length mismatch"
        extracted[name] = payload
        position = name_start + name_len + extra_len + comment_len

    assert extracted == expected, "selective local-header plus compressed-range extraction changed page bytes"

print("PASS: Torrent ZIP range fixture and storage-safety checks")
PY
