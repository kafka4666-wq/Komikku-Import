#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MANAGER="$ROOT/app/src/main/java/eu/kanade/tachiyomi/torrent/TorrentStreamManager.kt"
WORKER="$ROOT/app/src/main/java/exh/ui/torrent/TorrentImportWorker.kt"
FETCHER="$ROOT/app/src/main/java/eu/kanade/tachiyomi/data/coil/MangaCoverFetcher.kt"
SOURCE="$ROOT/app/src/main/java/eu/kanade/tachiyomi/source/online/TorrentSource.kt"
MORE_SCREEN="$ROOT/app/src/main/java/eu/kanade/presentation/more/MoreScreen.kt"
IMPORT_SCREEN="$ROOT/app/src/main/java/exh/ui/torrent/TorrentImportScreen.kt"
NOTIFICATION_RECEIVER="$ROOT/app/src/main/java/eu/kanade/tachiyomi/data/notification/NotificationReceiver.kt"

test -s "$MANAGER"
test -s "$WORKER"
test -s "$FETCHER"
test -s "$SOURCE"
test -s "$MORE_SCREEN"
test -s "$IMPORT_SCREEN"
test -s "$NOTIFICATION_RECEIVER"

python3 - "$MANAGER" "$WORKER" "$FETCHER" "$SOURCE" "$MORE_SCREEN" "$IMPORT_SCREEN" "$NOTIFICATION_RECEIVER" <<'PY'
from __future__ import annotations

import pathlib
import struct
import sys
import tempfile
import zipfile
import zlib

manager = pathlib.Path(sys.argv[1]).read_text()
worker = pathlib.Path(sys.argv[2]).read_text()
fetcher = pathlib.Path(sys.argv[3]).read_text()
source = pathlib.Path(sys.argv[4]).read_text()
more_screen = pathlib.Path(sys.argv[5]).read_text()
import_screen = pathlib.Path(sys.argv[6]).read_text()
notification_receiver = pathlib.Path(sys.argv[7]).read_text()

required_manager_markers = (
    "Semaphore(1)",
    "TEMPORARY_PIECE_BUDGET_BYTES = 64L * 1024L * 1024L",
    "REQUEST_DEADLINE_MILLIS = 45_000L",
    "remove(active.handle, remove_flags_t.from_int(1))",
    "active.catalog.saveDirectory.deleteRecursively()",
    "private suspend fun requestRange",
    "handle.unsetFlags(TorrentFlags.AUTO_MANAGED)",
    "handle.queuePositionTop()",
    "handle.forceReannounce()",
    "active.handle.setSequentialRange(firstPiece, lastPiece)",
    "it.startDht()",
    "range-request purpose=",
    "range-ready purpose=",
    "range-wait purpose=",
    "range-timeout purpose=",
    "stream-release book=",
)
for marker in required_manager_markers:
    assert marker in manager, f"missing storage safeguard: {marker}"

for forbidden in (
    "prefetchCovers(",
    "waitForFileComplete(",
    "filePriority(book.fileIndex, Priority.TOP_PRIORITY)",
    "writeCoverAtomically(",
    "coverWarm",
    "within 5 seconds",
):
    assert forbidden not in manager, f"forbidden Torrent manager behavior present: {forbidden}"

assert "prefetchCovers(" not in worker, "import worker must not prefetch all Torrent covers"
assert "manager.importLink(link)" in worker, "Torrent metadata import path is missing"
assert "networkToLocalManga(drafts, updateInfo = false)" in worker, "Torrent import no longer persists library records"
assert "updateManga.awaitAll" in worker and "favorite = true" in worker, "Torrent import no longer promotes imported records to the library"
assert "TorrentImportControl.awaitResume(context)" in worker, "Torrent import no longer honors Pause"
assert "TorrentImportControl.isCancelled(context)" in worker, "Torrent import no longer honors Cancel"

nhentai_position = more_screen.index('title = "Nhentai Book Import"')
torrent_position = more_screen.index('title = "Torrent"')
assert torrent_position > nhentai_position, "Torrent must remain directly below Nhentai Book Import"
assert "onClickTorrentImport" in more_screen, "Torrent menu action is missing"
for control in ("TorrentImportControl.pause(context)", "TorrentImportControl.resume(context)", "TorrentImportWorker.cancel(context)"):
    assert control in import_screen, f"Torrent import screen control missing: {control}"
for control in ("TorrentImportControl.pause(context)", "TorrentImportControl.resume(context)", "TorrentImportWorker.cancel(context)"):
    assert control in notification_receiver, f"Torrent notification control missing: {control}"

torrent_loader = fetcher.split("private suspend fun torrentCoverLoader", 1)[1].split("private suspend fun httpLoader", 1)[0]
assert "persistentFile" not in torrent_loader, "Torrent cover bytes must not be written to the persistent cover cache"
assert "ImageFetchResult(" in torrent_loader, "Torrent cover must be returned as an in-memory image result"
assert "SourceFetchResult(" not in torrent_loader, "Torrent cover must not expose a disk-cacheable image source"

all_books = manager.split("fun allBooks():", 1)[1].split("fun findBook", 1)[0]
for forbidden in ("ensureSession", "startSelectiveSession", "readCover", "requestRange"):
    assert forbidden not in all_books, f"source-tab browse started Torrent work: {forbidden}"

# CCDC06-scale browse regression: the source must page metadata rows before mapping them to UI
# objects and must not have a cover/page/media call anywhere in popular/latest/search functions.
source_browse = source.split("override suspend fun getPopularManga", 1)[1].split("override suspend fun getMangaUpdate", 1)[0]
for forbidden in ("readCover", "readPage", "pageNames", "ensureSession", "requestRange"):
    assert forbidden not in source_browse, f"source browse can start Torrent media work: {forbidden}"
assert "val pageSize = 40" in source, "Torrent browse page size is no longer bounded"
assert "val slice = books.drop(start).take(pageSize)" in source, "Torrent browse must slice before mapping to SManga"
assert "slice.map { it.toSManga() }" in source, "Torrent browse must only map the bounded slice"

with tempfile.TemporaryDirectory() as directory:
    index_path = pathlib.Path(directory) / "torrent.books.json"
    catalog = [
        {
            "key": f"fixture/{index}",
            "hash": "fixture",
            "fileIndex": index,
            "path": f"CCDC06/{index:05d}.cbz",
            "title": f"CCDC06 Fixture {index:05d}",
            "artist": "CCDC06",
            "size": 12 * 1024 * 1024,
        }
        for index in range(15_000)
    ]
    index_path.write_text(__import__("json").dumps(catalog))
    parsed = __import__("json").loads(index_path.read_text())
    assert len(parsed) == 15_000, "large metadata catalog was not retained"
    page_size = 40
    for page in (0, 1, 187, 374, 375, 376):
        start = max(page, 0) * page_size
        page_rows = parsed[start:start + page_size]
        assert len(page_rows) <= page_size, "large catalog page exceeded the UI bound"
        assert all(row["title"].startswith("CCDC06 Fixture") for row in page_rows)

with tempfile.TemporaryDirectory() as directory:
    archive = pathlib.Path(directory) / "fixture.cbz"
    expected = {
        "cover.jpg": b"\xff\xd8cover-bytes\xff\xd9",
        "001.png": b"\x89PNG\r\n\x1a\npage-one",
    }
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as out:
        for name, data in expected.items():
            out.writestr(name, data)

    raw = archive.read_bytes()
    tail = raw[-min(len(raw), 65557):]
    eocd = tail.rfind(b"PK\x05\x06")
    assert eocd >= 0, "EOCD was not found inside the allowed trailing scan"
    entries, directory_size, directory_offset = struct.unpack_from("<HII", tail, eocd + 10)
    assert entries == len(expected), "fixture central-directory entry count mismatch"
    assert directory_size > 0 and directory_offset > 0, "fixture directory location is invalid"

    position = directory_offset
    extracted = {}
    for _ in range(entries):
        assert raw[position:position + 4] == b"PK\x01\x02", "central-directory signature mismatch"
        flags, compression = struct.unpack_from("<HH", raw, position + 8)
        compressed_size, uncompressed_size = struct.unpack_from("<II", raw, position + 20)
        name_len, extra_len, comment_len = struct.unpack_from("<HHH", raw, position + 28)
        local_offset = struct.unpack_from("<I", raw, position + 42)[0]
        name_start = position + 46
        name = raw[name_start:name_start + name_len].decode("utf-8")
        local_name_len, local_extra_len = struct.unpack_from("<HH", raw, local_offset + 26)
        assert raw[local_offset:local_offset + 4] == b"PK\x03\x04", "local-header signature mismatch"
        payload_start = local_offset + 30 + local_name_len + local_extra_len
        payload = raw[payload_start:payload_start + compressed_size]
        if compression == zipfile.ZIP_DEFLATED:
            payload = zlib.decompress(payload, -zlib.MAX_WBITS)
        assert len(payload) == uncompressed_size, "range extraction length mismatch"
        extracted[name] = payload
        position = name_start + name_len + extra_len + comment_len

    assert extracted == expected, "selective local-header plus compressed-range extraction changed page bytes"

print("PASS: Torrent ZIP range fixture and storage-safety checks")
PY
