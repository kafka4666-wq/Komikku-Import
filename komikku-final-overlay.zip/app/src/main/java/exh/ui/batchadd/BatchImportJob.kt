package exh.ui.batchadd

import android.content.Context
import android.net.Uri
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.PowerManager
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import eu.kanade.domain.manga.interactor.UpdateManga
import eu.kanade.domain.ui.KomikkuExtendedFeatureStore
import eu.kanade.tachiyomi.R
import eu.kanade.tachiyomi.data.BatchImportStatus
import eu.kanade.tachiyomi.data.notification.NotificationReceiver
import eu.kanade.tachiyomi.data.notification.Notifications
import eu.kanade.tachiyomi.util.system.cancelNotification
import eu.kanade.tachiyomi.util.system.notificationBuilder
import eu.kanade.tachiyomi.util.system.notify
import eu.kanade.tachiyomi.util.system.setForegroundSafely
import eu.kanade.tachiyomi.util.system.workManager
import exh.GalleryAddEvent
import exh.GalleryAdder
import exh.source.nHentaiSourceIds
import exh.log.xLogE
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import tachiyomi.domain.manga.model.MangaUpdate
import tachiyomi.domain.manga.repository.MangaRepository
import tachiyomi.domain.storage.service.StoragePreferences
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import com.hippo.unifile.UniFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

/** A single process-wide gate shared by discovery and library insertion. */
object BatchImportRequestLimiter {
    // Keep normal imports at the current speed. A 429 is handled with a
    // targeted cooldown below instead of slowing every request globally.
    private const val REQUEST_INTERVAL_MS = 1_500L
    private val mutex = Mutex()
    private var nextRequestAt = 0L

    suspend fun await(intervalMs: Long = REQUEST_INTERVAL_MS) {
        val waitFor = mutex.withLock {
            val now = System.currentTimeMillis()
            val wait = (nextRequestAt - now).coerceAtLeast(0L)
            nextRequestAt = maxOf(now, nextRequestAt) + intervalMs
            wait
        }
        if (waitFor > 0) delay(waitFor)
    }
}

class BatchImportJob(
    private val context: Context,
    workerParams: WorkerParameters,
) : CoroutineWorker(context, workerParams) {
    private val status: BatchImportStatus = Injekt.get()
    private val storagePreferences: StoragePreferences = Injekt.get()
    private val mangaRepository: MangaRepository = Injekt.get()
    private val updateManga: UpdateManga = Injekt.get()
    private val identityRepairLock = Mutex()
    private val repairedIdentities = mutableSetOf<String>()

    override suspend fun doWork(): Result {
        val inputPath = inputData.getString(INPUT_PATH) ?: return Result.failure()
        val nhentaiImport = inputData.getBoolean(KEY_NHENTAI_IMPORT, false)
        val fastTitleImport = inputData.getBoolean(KEY_FAST_TITLE_IMPORT, false)
        val progressNotificationId = if (nhentaiImport) Notifications.ID_NHENTAI_BATCH_IMPORT_PROGRESS else Notifications.ID_BATCH_IMPORT_PROGRESS
        val inputFile = File(inputPath)
        val checkpointFile = File("$inputPath.progress")
        val failedFile = File("$inputPath.failed")
        val eventsFile = File("$inputPath.events")
        val doneFile = File("$inputPath.done")
        var urls = inputFile.readCompleteLinesSafely().toMutableList()
        if (urls.isEmpty() && !inputFile.exists()) return Result.failure()
        var nextIndex = checkpointFile.readLinesSafely().firstOrNull()?.trim()?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        var failedLinks = failedFile.readLinesSafely().toMutableList()
        var added = (nextIndex - failedLinks.size).coerceAtLeast(0)
        var failed = failedLinks.size.coerceAtMost(nextIndex)
        var announcedTotal = -1

        status.begin(urls.size, nextIndex.coerceAtMost(urls.size), added, failed, eventsFile.readLinesSafely())
        val wakeLock = context.getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Komikku:BatchImport")
        wakeLock.acquire()
        setForegroundSafely()
        setProgress(progressData(nextIndex, urls.size, added, failed))
        showProgress(nextIndex, urls.size, added, failed)

        return try {
            while (true) {
                val available = inputFile.readCompleteLinesSafely()
                if (available.size > urls.size) {
                    urls.addAll(available.drop(urls.size))
                }
                if (urls.size != announcedTotal) {
                    status.begin(urls.size, nextIndex.coerceAtMost(urls.size), added, failed, eventsFile.readLinesSafely())
                    announcedTotal = urls.size
                    setProgress(progressData(nextIndex, urls.size, added, failed))
                    showProgress(nextIndex, urls.size, added, failed)
                }

                if (nextIndex < urls.size) {
                    val url = urls[nextIndex]
                    repairExistingNhentaiIdentity(url)
                    val result = addGalleryRateLimited(url, fastTitleImport)
                    val wasAdded = result is GalleryAddEvent.Success
                    val detail = if (wasAdded) null else result.logMessage
                    if (wasAdded) {
                        added++
                    } else {
                        failed++
                        failedLinks += url
                        failedFile.appendLineSafely(url)
                    }
                    val event = if (wasAdded) "[ADDED] $url" else "[FAILED] $url${detail?.takeIf { it.isNotBlank() }?.let { " — $it" } ?: ""}"
                    eventsFile.appendLineSafely(event)
                    nextIndex++
                    checkpointFile.writeText(nextIndex.toString())
                    status.record(url, wasAdded, detail)
                    setProgress(progressData(nextIndex, urls.size, added, failed))
                    showProgress(nextIndex, urls.size, added, failed)
                    continue
                }

                if (doneFile.exists()) break
                delay(PAUSE_POLL_MS)
            }

            writeLinksFile("batch_import_failed_links", failedLinks)
            showComplete(nextIndex, urls.size, added, failed)
            Result.success(progressData(nextIndex, urls.size, added, failed))
        } catch (cancelled: CancellationException) {
            withContext(NonCancellable) {
                val currentUrls = inputFile.readCompleteLinesSafely()
                writeUnprocessedLinks(currentUrls, nextIndex, failedLinks)
                KomikkuExtendedFeatureStore.recordRecovery(context, "batch_import_cancelled", "Saved checkpoint at ${nextIndex}/${currentUrls.size}")
                status.restore(currentUrls.size, nextIndex.coerceAtMost(currentUrls.size), added, failed, eventsFile.readLinesSafely(), running = false)
            }
            throw cancelled
        } catch (error: Throwable) {
            xLogE("Batch import error", error)
            withContext(NonCancellable) {
                val currentUrls = inputFile.readCompleteLinesSafely()
                writeUnprocessedLinks(currentUrls, nextIndex, failedLinks)
                KomikkuExtendedFeatureStore.recordRecovery(context, "batch_import_retry", "Saved checkpoint at ${nextIndex}/${currentUrls.size}: ${error.javaClass.simpleName}")
                status.restore(currentUrls.size, nextIndex.coerceAtMost(currentUrls.size), added, failed, eventsFile.readLinesSafely(), running = false)
            }
            Result.retry()
        } finally {
            if (wakeLock.isHeld) wakeLock.release()
            context.cancelNotification(progressNotificationId)
            if (!isStopped && doneFile.exists() && nextIndex >= inputFile.readCompleteLinesSafely().size) {
                inputFile.delete()
                checkpointFile.delete()
                failedFile.delete()
                eventsFile.delete()
                doneFile.delete()
            }
        }
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = ForegroundInfo(
        inputData.getInt(KEY_NOTIFICATION_ID, Notifications.ID_BATCH_IMPORT_PROGRESS),
        buildProgressNotification(0, 1, 0, 0, inputData.getBoolean(KEY_NHENTAI_IMPORT, false)),
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0,
    )

    /**
     * The source grid marks a result as present by querying (manga.url, manga.source).
     * Older importer builds could resolve the same nhentai gallery through a different
     * delegated language/source ID. Repair that key before GalleryAdder looks it up,
     * preserving the existing row, favorite state, chapters, and categories.
     */
    private suspend fun repairExistingNhentaiIdentity(url: String) {
        val identity = runCatching { GalleryAdder().canonicalMangaIdentity(url) }.getOrNull() ?: return
        val canonicalUrl = identity.second.trimEnd('/').ifBlank { return }
        val targetSource = identity.first
        identityRepairLock.withLock {
            if (!repairedIdentities.add("$targetSource:$canonicalUrl")) return

            // Do not load the entire library here. A large library makes that query
            // materialize every category/chapter aggregate and was the direct cause
            // of OOMs while automatic nhentai addition was running. Query only the
            // small set of possible nhentai source IDs for this one gallery.
            val sourceIds = (nHentaiSourceIds + targetSource).distinct()
            for (sourceId in sourceIds) {
                if (sourceId == targetSource) continue
                val existing = mangaRepository.getMangaByUrlAndSourceId(canonicalUrl, sourceId) ?: continue
                if (updateManga.await(MangaUpdate(id = existing.id, source = targetSource))) {
                    break
                }
            }
        }
    }

    private suspend fun addGalleryRateLimited(url: String, fastTitleImport: Boolean = false): GalleryAddEvent {
        awaitResume()
        var result: GalleryAddEvent = GalleryAddEvent.Fail.Error(url, "Transient retry exhausted")
        for (attempt in 0 until MAX_ADD_ATTEMPTS) {
            awaitResume()
            BatchImportRequestLimiter.await(if (fastTitleImport) FAST_TITLE_INTERVAL_MS else NORMAL_TITLE_INTERVAL_MS)
            val startedAt = System.currentTimeMillis()
            result = GalleryAdder().addGallery(context = context, url = url, fav = true, retry = INNER_ADD_RETRIES)
            val elapsed = System.currentTimeMillis() - startedAt
            val rateLimited = isRateLimited(result)
            KomikkuExtendedFeatureStore.recordSourceEvent(
                context = context,
                source = "nhentai",
                kind = if (rateLimited) "rate_limit" else "import",
                success = result is GalleryAddEvent.Success,
                latencyMs = elapsed,
                error = (result as? GalleryAddEvent.Fail.Error)?.logMessage,
            )
            if (result is GalleryAddEvent.Success || !isTransientFailure(result)) return result
            if (attempt < MAX_ADD_ATTEMPTS - 1) {
                val pause = if (rateLimited) {
                    (RATE_LIMIT_COOLDOWN_MS * (1L shl attempt)).coerceAtMost(MAX_RATE_LIMIT_COOLDOWN_MS)
                } else {
                    (TRANSIENT_COOLDOWN_MS * (attempt + 1)).coerceAtMost(MAX_TRANSIENT_COOLDOWN_MS)
                }
                delay(pause)
            }
        }
        return result
    }

    private suspend fun awaitResume() {
        while (isPaused(context)) delay(PAUSE_POLL_MS)
    }

    private fun isRateLimited(result: GalleryAddEvent): Boolean =
        result is GalleryAddEvent.Fail.Error && result.logMessage.lowercase().let {
            "429" in it || "too many request" in it || "rate limit" in it || "rate-limit" in it
        }

    private fun isTransientFailure(result: GalleryAddEvent): Boolean {
        if (result !is GalleryAddEvent.Fail.Error) return false
        if (result is GalleryAddEvent.Fail.NotFound) return false
        val message = result.logMessage.lowercase()
        return listOf(
            "429", "too many request", "rate limit", "rate-limit", "timeout",
            "timed out", "connection", "connect", "network", "socket", "reset",
            "refused", "unreachable", "unavailable", "eof", "broken pipe",
            "5xx", "500", "502", "503", "504", "ssl",
        ).any(message::contains)
    }

    private fun buildProgressNotification(completed: Int, total: Int, added: Int, failed: Int, nhentaiImport: Boolean = false) =
        context.notificationBuilder(if (nhentaiImport) Notifications.CHANNEL_NHENTAI_BATCH_IMPORT_PROGRESS else Notifications.CHANNEL_BATCH_IMPORT_PROGRESS) {
            setSmallIcon(R.drawable.ic_komikku)
            setContentTitle("Adding manga")
            setContentText("${if (total == 0) 0 else completed * 100 / total}% • $completed/$total processed • $added added • $failed failed")
            setProgress(total.coerceAtLeast(1), completed, false)
            setOngoing(true)
            setOnlyAlertOnce(true)
            setAutoCancel(false)
            setSubText("${if (total == 0) 0 else completed * 100 / total}%")
            addAction(R.drawable.ic_pause_24dp, "Pause", NotificationReceiver.pauseBatchImportPendingBroadcast(context))
            addAction(R.drawable.ic_play_arrow_24dp, "Resume", NotificationReceiver.resumeBatchImportPendingBroadcast(context))
            addAction(R.drawable.ic_close_24dp, "Cancel", NotificationReceiver.cancelBatchImportPendingBroadcast(context))
        }.build()

    private fun showProgress(completed: Int, total: Int, added: Int, failed: Int) {
        val nhentaiImport = inputData.getBoolean(KEY_NHENTAI_IMPORT, false)
        context.notify(if (nhentaiImport) Notifications.ID_NHENTAI_BATCH_IMPORT_PROGRESS else Notifications.ID_BATCH_IMPORT_PROGRESS, buildProgressNotification(completed, total, added, failed, nhentaiImport))
    }

    private fun progressData(completed: Int, total: Int, added: Int, failed: Int) = workDataOf(
        KEY_COMPLETED to completed,
        KEY_TOTAL to total,
        KEY_ADDED to added,
        KEY_FAILED to failed,
    )

    private fun showComplete(completed: Int, total: Int, added: Int, failed: Int) {
        // Stop the app-wide banner as soon as the queue is fully drained. A later
        // import calls begin() again, so the banner reappears for the new job.
        status.restore(total, completed, added, failed, status.state.value.events, running = false)
        val nhentaiImport = inputData.getBoolean(KEY_NHENTAI_IMPORT, false)
        context.cancelNotification(if (nhentaiImport) Notifications.ID_NHENTAI_BATCH_IMPORT_PROGRESS else Notifications.ID_BATCH_IMPORT_PROGRESS)
        context.notificationBuilder(if (nhentaiImport) Notifications.CHANNEL_NHENTAI_BATCH_IMPORT_PROGRESS else Notifications.CHANNEL_BATCH_IMPORT_COMPLETE) {
            setSmallIcon(R.drawable.ic_komikku)
            setContentTitle("Manga adding complete")
            setContentText("100% • $completed/$total processed • $added added • $failed failed")
            setAutoCancel(true)
        }.also { context.notify(if (nhentaiImport) Notifications.ID_NHENTAI_BATCH_IMPORT_COMPLETE else Notifications.ID_BATCH_IMPORT_COMPLETE, it.build()) }
    }

    private fun writeUnprocessedLinks(urls: List<String>, nextIndex: Int, failedLinks: List<String>) {
        val pending = urls.drop(nextIndex)
        writeLinksFile("batch_import_unprocessed_links", (failedLinks + pending).distinct())
    }

    private fun writeLinksFile(prefix: String, links: List<String>) {
        if (links.isEmpty()) return
        runCatching {
            val directory = UniFile.fromUri(context, Uri.parse(storagePreferences.baseStorageDirectory().get())) ?: return
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = directory.createFile("${prefix}_$timestamp.txt") ?: return
            file.openOutputStream().bufferedWriter().use { writer -> links.distinct().forEach(writer::appendLine) }
        }.onFailure { xLogE("Batch-link export error", it) }
    }

    private fun File.readLinesSafely(): List<String> = runCatching { if (exists()) readLines().filter(String::isNotBlank) else emptyList() }.getOrDefault(emptyList())

    /** Ignore a concurrently appended, unterminated final URL. */
    private fun File.readCompleteLinesSafely(): List<String> = runCatching {
        if (!exists()) return@runCatching emptyList()
        val text = readText()
        val end = text.lastIndexOf('\n')
        if (end < 0) return@runCatching emptyList()
        text.substring(0, end)
            .lineSequence()
            .map(String::trim)
            .filter(String::isNotBlank)
            .toList()
    }.getOrDefault(emptyList())

    private fun File.appendLineSafely(value: String) {
        parentFile?.mkdirs()
        appendText(value + "\n")
    }

    companion object {
        private const val TAG = "BatchImport"
        private const val INPUT_PATH = "input_path"
        private const val KEY_NHENTAI_IMPORT = "nhentai_import"
        private const val KEY_NOTIFICATION_ID = "notification_id"
        private const val RATE_LIMIT_COOLDOWN_MS = 60_000L
        private const val MAX_RATE_LIMIT_COOLDOWN_MS = 10 * 60_000L
        private const val MAX_ADD_ATTEMPTS = 4
        private const val INNER_ADD_RETRIES = 2
        private const val PAUSE_POLL_MS = 500L
        private const val TRANSIENT_COOLDOWN_MS = 10_000L
        private const val MAX_TRANSIENT_COOLDOWN_MS = 60_000L
        private const val NORMAL_TITLE_INTERVAL_MS = 1_500L
        private const val FAST_TITLE_INTERVAL_MS = 500L
        private const val PREFS_NAME = "batch_import_controls"
        private const val PREFS_PAUSED = "paused"
        private const val PREF_JOB_ID = "batch_import_job_id"

        private fun prefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        fun isPaused(context: Context): Boolean = prefs(context).getBoolean(PREFS_PAUSED, false)
        fun pause(context: Context) { prefs(context).edit().putBoolean(PREFS_PAUSED, true).apply() }
        fun resume(context: Context) { prefs(context).edit().putBoolean(PREFS_PAUSED, false).apply() }

        fun start(context: Context, urls: List<String>): UUID {
            val input = File(context.cacheDir, "batch-import-${System.currentTimeMillis()}.txt")
            input.writeText(if (urls.isEmpty()) "" else urls.joinToString("\n") + "\n")
            File("${input.absolutePath}.done").writeText("done")
            return enqueue(context, input, TAG, androidx.work.ExistingWorkPolicy.REPLACE, saveJobId = true)
        }

        fun startTitleMatches(context: Context, urls: List<String>): UUID {
            val input = File(context.cacheDir, "batch-title-import-${System.currentTimeMillis()}.txt")
            input.writeText(if (urls.isEmpty()) "" else urls.joinToString("\n") + "\n")
            File("${input.absolutePath}.done").writeText("done")
            return enqueue(
                context,
                input,
                "$TAG-title-matches",
                androidx.work.ExistingWorkPolicy.REPLACE,
                saveJobId = true,
                fastTitleImport = true,
            )
        }

        fun startFromFile(context: Context, input: File) {
            input.parentFile?.mkdirs()
            if (!input.exists()) input.createNewFile()
            // Discovery retries must not replace a worker that is already draining
            // this same growing file. Use a queue-specific name so a second manual
            // or daily nhentai import cannot strand its URLs behind an older queue.
            enqueue(context, input, queueWorkName(input), androidx.work.ExistingWorkPolicy.KEEP, saveJobId = false, nhentaiImport = true)
        }

        fun savedJobId(context: Context): String? = prefs(context).getString(PREF_JOB_ID, null)

        private fun enqueue(
            context: Context,
            input: File,
            workName: String,
            policy: androidx.work.ExistingWorkPolicy,
            saveJobId: Boolean,
            nhentaiImport: Boolean = false,
            fastTitleImport: Boolean = false,
        ): UUID {
            val requestId = UUID.randomUUID()
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequestBuilder<BatchImportJob>()
                .setConstraints(constraints)
                .setId(requestId)
                .setInputData(workDataOf(INPUT_PATH to input.absolutePath, KEY_NHENTAI_IMPORT to nhentaiImport, KEY_FAST_TITLE_IMPORT to fastTitleImport, KEY_NOTIFICATION_ID to if (nhentaiImport) Notifications.ID_NHENTAI_BATCH_IMPORT_PROGRESS else Notifications.ID_BATCH_IMPORT_PROGRESS))
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag(TAG)
                .build()
            context.workManager.enqueueUniqueWork(workName, policy, request)
            if (saveJobId) prefs(context).edit().putString(PREF_JOB_ID, requestId.toString()).apply()
            return requestId
        }

        private fun queueWorkName(input: File): String = "$TAG-${input.absolutePath.hashCode()}"

        fun stop(context: Context) {
            // Queue workers have per-file unique names; cancel by the shared tag.
            context.workManager.cancelAllWorkByTag(TAG)
        }

        fun cancel(context: Context) {
            resume(context)
            stop(context)
        }

        const val KEY_COMPLETED = "completed"
        const val KEY_TOTAL = "total"
        const val KEY_ADDED = "added"
        const val KEY_FAILED = "failed"
        private const val KEY_FAST_TITLE_IMPORT = "fast_title_import"
    }
}
