package eu.kanade.tachiyomi.ui.discover

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.core.model.StateScreenModel
import cafe.adriel.voyager.core.model.rememberScreenModel
import cafe.adriel.voyager.core.model.screenModelScope
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.Navigator
import cafe.adriel.voyager.navigator.tab.LocalTabNavigator
import cafe.adriel.voyager.navigator.tab.TabOptions
import eu.kanade.presentation.util.Screen
import eu.kanade.presentation.util.Tab
import eu.kanade.tachiyomi.ui.manga.MangaScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tachiyomi.domain.manga.interactor.NetworkToLocalManga
import tachiyomi.domain.manga.model.Manga
import tachiyomi.domain.manga.model.MangaUpdate
import tachiyomi.domain.manga.repository.MangaRepository
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import mihon.domain.manga.model.toDomainManga

private const val MAX_DISCOVER_ENTRIES = 600
private const val MAX_ENTRIES_PER_SOURCE = 30

data object DiscoverTab : Tab {
    private fun readResolve(): Any = DiscoverTab

    override val options: TabOptions
        @Composable
        get() {
            val selected = LocalTabNavigator.current.current.key == key
            return TabOptions(
                index = 1u,
                title = "Discover",
                icon = androidx.compose.ui.graphics.vector.rememberVectorPainter(
                    if (selected) Icons.Outlined.Explore else Icons.Outlined.Explore,
                ),
            )
        }

    override suspend fun onReselect(navigator: Navigator) {
        navigator.push(DoujinDiscoverScreen())
    }

    @Composable
    override fun Content() {
        DoujinDiscoverContent()
    }
}

private enum class DiscoverMode(val label: String) {
    LATEST("Latest"),
    POPULAR("Popular"),
}

private data class DiscoverEntry(
    val manga: Manga,
    val sourceName: String,
)

private data class DiscoverState(
    val mode: DiscoverMode = DiscoverMode.LATEST,
    val items: List<DiscoverEntry> = emptyList(),
    val isLoading: Boolean = false,
    val status: String = "Choose Latest or Popular to load all visible installed extensions.",
)

private class DiscoverScreenModel(
    private val sourceManager: SourceManager = Injekt.get(),
    private val networkToLocalManga: NetworkToLocalManga = Injekt.get(),
) : StateScreenModel<DiscoverState>(DiscoverState()) {

    fun refresh(mode: DiscoverMode = state.value.mode) {
        if (state.value.isLoading) return
        mutableState.update { it.copy(mode = mode, isLoading = true, status = "Loading ${mode.label.lowercase()} results from installed extensions…") }
        screenModelScope.launch {
            val sources = sourceManager.getVisibleOnlineSources()
            val sourceNames = sources.associate { it.id to it.name }
            val batches = sources.map { source ->
                async(Dispatchers.IO) {
                    runCatching {
                        val page = when {
                            mode == DiscoverMode.LATEST && source.supportsLatest -> source.getLatestUpdates(1)
                            else -> source.getPopularManga(1)
                        }
                        page.mangas
                            .take(MAX_ENTRIES_PER_SOURCE)
                            .map { it.toDomainManga(source.id) }
                    }.getOrElse { emptyList() }
                }
            }.awaitAll()
            val remote = batches.flatten()
            val local = withContext(Dispatchers.IO) {
                runCatching {
                    networkToLocalManga(remote, updateInfo = false)
                }.getOrElse { emptyList() }
            }
            val entries = local.asSequence()
                .filterNot { it.favorite }
                .distinctBy { "${it.source}:${it.url}" }
                .take(MAX_DISCOVER_ENTRIES)
                .map { DiscoverEntry(it, sourceNames[it.source] ?: "Source ${it.source}") }
                .toList()
            mutableState.update {
                it.copy(
                    mode = mode,
                    items = entries,
                    isLoading = false,
                    status = "${entries.size} titles from ${sources.size} installed extensions. Library items are hidden; results are capped only to keep the UI responsive.",
                )
            }
        }
    }
}

class DoujinDiscoverScreen : Screen() {
    @Composable
    override fun Content() {
        DoujinDiscoverContent()
    }
}

@Composable
private fun DoujinDiscoverContent() {
    val navigator = LocalNavigator.current ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val screenModel = rememberScreenModel { DiscoverScreenModel() }
    val state: DiscoverState = screenModel.state.collectAsState().value
    val repository = remember { Injekt.get<MangaRepository>() }
    var selectedIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var isAdding by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        screenModel.refresh()
    }

    val selectedEntries = state.items.filter { it.manga.id in selectedIds }

    fun selectAll() {
        selectedIds = state.items.asSequence().map { it.manga.id }.toSet()
    }

    fun addSelected() {
        if (selectedEntries.isEmpty() || isAdding) return
        isAdding = true
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val local = repository.insertNetworkManga(
                        selectedEntries.map { it.manga },
                        updateInfo = false,
                    )
                    val newFavorites = local.filterNot { it.favorite }
                    if (newFavorites.isNotEmpty()) {
                        repository.updateAll(newFavorites.map { MangaUpdate(id = it.id, favorite = true) })
                    }
                    newFavorites.size
                }
            }.onSuccess { count ->
                selectedIds = emptySet()
                screenModel.refresh(state.mode)
                android.widget.Toast.makeText(context, "Added $count titles to Library", android.widget.Toast.LENGTH_SHORT).show()
            }.onFailure { error ->
                android.widget.Toast.makeText(context, "Could not add titles: ${error.message?.take(120) ?: "database error"}", android.widget.Toast.LENGTH_LONG).show()
            }
            isAdding = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Discover") },
                navigationIcon = { TextButton(onClick = navigator::pop) { Text("Back") } },
                actions = {
                    IconButton(onClick = { screenModel.refresh(state.mode) }, enabled = !state.isLoading && !isAdding) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Refresh")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("All installed extensions", style = MaterialTheme.typography.titleMedium)
                    Text("Latest or popular doujins are combined into one feed. Items already in Library are excluded.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(enabled = !state.isLoading, onClick = { selectedIds = emptySet(); screenModel.refresh(DiscoverMode.LATEST) }) { Text(if (state.mode == DiscoverMode.LATEST) "[Latest]" else "Latest") }
                        TextButton(enabled = !state.isLoading, onClick = { selectedIds = emptySet(); screenModel.refresh(DiscoverMode.POPULAR) }) { Text(if (state.mode == DiscoverMode.POPULAR) "[Popular]" else "Popular") }
                        TextButton(enabled = state.items.isNotEmpty() && !state.isLoading, onClick = ::selectAll) { Text("Select all") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = selectedEntries.isNotEmpty() && !isAdding, onClick = ::addSelected) {
                            Text(if (isAdding) "Adding…" else "Add ${selectedEntries.size} to library")
                        }
                        TextButton(enabled = selectedIds.isNotEmpty(), onClick = { selectedIds = emptySet() }) { Text("Clear") }
                    }
                    Text(state.status, style = MaterialTheme.typography.labelSmall)
                }
            }
            items(state.items, key = { "discover-${it.manga.source}-${it.manga.url}" }) { entry ->
                val manga = entry.manga
                val selected = manga.id in selectedIds
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { navigator.push(MangaScreen(manga.id)) },
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Checkbox(
                            checked = selected,
                            onCheckedChange = {
                                selectedIds = if (it) selectedIds + manga.id else selectedIds - manga.id
                            },
                        )
                        coil3.compose.AsyncImage(
                            model = manga.thumbnailUrl,
                            contentDescription = manga.title,
                            modifier = Modifier.size(72.dp),
                        )
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(manga.title, style = MaterialTheme.typography.titleSmall)
                            Text(entry.sourceName, style = MaterialTheme.typography.labelMedium)
                            Text(manga.genre.orEmpty().take(4).joinToString(), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}
