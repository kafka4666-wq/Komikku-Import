package eu.kanade.tachiyomi.data.download.dailycache

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import eu.kanade.domain.ui.KodamiTreasuryPreferences
import eu.kanade.tachiyomi.data.notification.NotificationReceiver
import eu.kanade.tachiyomi.data.download.DownloadManager
import java.io.File
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import tachiyomi.domain.chapter.interactor.GetChaptersByMangaId
import tachiyomi.domain.chapter.model.Chapter
import tachiyomi.domain.library.model.LibraryManga
import tachiyomi.domain.manga.interactor.GetLibraryManga
import tachiyomi.domain.manga.interactor.GetManga
import tachiyomi.domain.manga.model.Manga
import tachiyomi.domain.source.service.SourceManager
import eu.kanade.tachiyomi.source.online.HttpSource
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

object DailyOfflineCacheJob {
    private const val CACHE_WORK_PREFIX = "komikku-daily-cache-"

    fun enqueue(context: Context): Boolean {
        val today = LocalDate.now().toString()
        val request = OneTimeWorkRequestBuilder<DailyOfflineCacheWorker>().build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "$CACHE_WORK_PREFIX$today",
            ExistingWorkPolicy.KEEP,
            request,
        )
        return true
    }
}

class DailyOfflineCacheWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val result = DailyOfflineCacheManager(applicationContext).cacheToday()
        Result.success(
            workDataOf(
                OUTPUT_TITLE_COUNT to result.titleCount,
                OUTPUT_CHAPTER_COUNT to result.newlyQueuedChapterCount,
            ),
        )
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        const val OUTPUT_TITLE_COUNT = "title_count"
        const val OUTPUT_CHAPTER_COUNT = "new_chapter_count"
    }
}

class DailyOfflineCacheCleanupWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        DailyOfflineCacheManager(applicationContext).expireIfNeeded()
        scheduleNext(applicationContext)
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        private const val CLEANUP_WORK_PREFIX = "komikku-daily-cache-expiry-"

        fun enqueueNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<DailyOfflineCacheCleanupWorker>().build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "${CLEANUP_WORK_PREFIX}now",
                ExistingWorkPolicy.REPLACE,
                request,
            )
        }

        /** WorkManager is persisted across process death and reboot; expireIfNeeded also runs on app resume. */
        fun scheduleNext(context: Context) {
            val zone = ZoneId.systemDefault()
            val now = java.time.ZonedDateTime.now(zone)
            val nextDate = now.toLocalDate().plusDays(1)
            val nextMidnight = nextDate.atStartOfDay(zone)
            val delayMillis = Duration.between(now, nextMidnight).toMillis().coerceAtLeast(1_000L)
            val request = OneTimeWorkRequestBuilder<DailyOfflineCacheCleanupWorker>()
                .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "$CLEANUP_WORK_PREFIX$nextDate",
                ExistingWorkPolicy.REPLACE,
                request,
            )
            val alarmIntent = Intent(context, NotificationReceiver::class.java).apply {
                action = NotificationReceiver.ACTION_DAILY_CACHE_CLEANUP_ALARM
            }
            val alarmPendingIntent = PendingIntent.getBroadcast(
                context,
                0xDA1, // Stable request code: keep one cleanup alarm.
                alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        nextMidnight.toInstant().toEpochMilli(),
                        alarmPendingIntent,
                    )
                } else {
                    alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        nextMidnight.toInstant().toEpochMilli(),
                        alarmPendingIntent,
                    )
                }
            }
        }
    }
}

class DailyOfflineCacheManager(
    private val context: Context,
    private val preferences: KodamiTreasuryPreferences = KodamiTreasuryPreferences(Injekt.get()),
    private val getLibraryManga: GetLibraryManga = Injekt.get(),
    private val getChaptersByMangaId: GetChaptersByMangaId = Injekt.get(),
    private val getManga: GetManga = Injekt.get(),
    private val downloadManager: DownloadManager = Injekt.get(),
    private val sourceManager: SourceManager = Injekt.get(),
) {
    private val recordsFile: File
        get() = File(context.filesDir, "komikku-daily-cache-owned-chapters.txt")

    suspend fun cacheToday(): CacheResult = withContext(Dispatchers.IO) {
        expireIfNeeded()
        val today = LocalDate.now().toString()
        val existingDate = preferences.dailyCacheDate().get()
        val existingIds = parseIds(preferences.dailyCacheMangaIds().get())
        if (existingDate == today && existingIds.isNotEmpty()) {
            preferences.dailyCacheStatus().set("Today's cache is already ready (${existingIds.size} titles).")
            return@withContext CacheResult(existingIds.size, 0)
        }

        val selected = mutableListOf<CachedTitle>()
        val library: List<LibraryManga> = getLibraryManga.await()
        for (entry in library.filter { it.totalChapters > 0 }.shuffled()) {
            if (selected.size >= TITLES_PER_DAY) break
            val manga = entry.manga
            if (sourceManager.get(manga.source) !is HttpSource) continue
            val chapters = getChaptersByMangaId.await(manga.id, applyFilter = false)
                .filter { it.id > 0L }
            if (chapters.isNotEmpty()) selected += CachedTitle(manga, chapters)
        }
        if (selected.isEmpty()) {
            preferences.dailyCacheStatus().set("No eligible library titles with available chapters were found.")
            return@withContext CacheResult(0, 0)
        }

        val newlyQueued = mutableListOf<Pair<Long, Long>>()
        selected.forEach { title ->
            val queued = downloadManager.downloadChaptersTracked(title.manga, title.chapters)
            queued.forEach { chapter -> newlyQueued += title.manga.id to chapter.id }
        }

        // Persist ownership before starting the queue. At midnight, only chapters newly
        // admitted by this job are deleted; favorited titles are retained explicitly.
        writeRecords(newlyQueued)
        val retainedIds = readRecords().map { it.first }.distinct()
        preferences.dailyCacheMangaIds().set((retainedIds + selected.map { it.manga.id }).distinct().joinToString(","))
        preferences.dailyCacheDate().set(today)
        downloadManager.startDownloads()
        preferences.dailyCacheStatus().set(
            "Prepared ${selected.size} titles; queued ${newlyQueued.size} new chapters.",
        )
        CacheResult(selected.size, newlyQueued.size)
    }

    suspend fun expireIfNeeded() = withContext(Dispatchers.IO) {
        val cacheDate = preferences.dailyCacheDate().get()
        val today = LocalDate.now().toString()
        val protectedIds = parseIds(preferences.dailyCacheProtectedMangaIds().get()).toSet()
        val records = readRecords()
        val cachedIds = parseIds(preferences.dailyCacheMangaIds().get())
        // A previous cleanup could have cleared the date marker while leaving
        // ownership records behind. Those records must remain retryable.
        if (records.isEmpty() && cachedIds.isEmpty()) return@withContext
        if (cacheDate.isNotBlank() && cacheDate >= today) return@withContext

        val retained = mutableListOf<Pair<Long, Long>>()
        records.groupBy { it.first }.forEach { (mangaId, mangaRecords) ->
            val manga = getManga.await(mangaId)
            if (manga == null) {
                retained += mangaRecords
                return@forEach
            }
            // Being in the library is not protection: the daily cache selects
            // library titles by design. Only the explicit Keep cached
            // action may retain this title across midnight.
            if (mangaId in protectedIds) {
                retained += mangaRecords
                return@forEach
            }
            val source = sourceManager.get(manga.source)
            if (source == null) {
                retained += mangaRecords
                return@forEach
            }
            val wantedChapterIds = mangaRecords.mapTo(hashSetOf()) { it.second }
            val ownedChapters = getChaptersByMangaId.await(mangaId, applyFilter = false)
                .filter { it.id in wantedChapterIds }
            if (ownedChapters.isNotEmpty()) {
                downloadManager.deleteChaptersNow(
                    chapters = ownedChapters,
                    manga = manga,
                    source = source,
                    ignoreCategoryExclusion = true,
                )
            }
        }

        val recordsSaved = if (retained.isEmpty()) {
            synchronized(RECORDS_LOCK) {
                !recordsFile.exists() || recordsFile.delete()
            }
        } else {
            writeRecords(retained, replace = true)
        }
        // Do not clear the date/IDs if the ownership file could not be
        // updated. The next startup, alarm, or manual cleanup can retry it.
        if (!recordsSaved) return@withContext
        preferences.dailyCacheMangaIds().set(retained.map { it.first }.distinct().joinToString(","))
        preferences.dailyCacheChapterRecords().set("")
        preferences.dailyCacheDate().set("")
        preferences.dailyCacheStatus().set("")
    }

    private fun writeRecords(records: List<Pair<Long, Long>>, replace: Boolean = false): Boolean =
        synchronized(RECORDS_LOCK) {
            val merged = if (replace) records.distinct() else (readRecords() + records).distinct()
            val tempFile = File(context.filesDir, "komikku-daily-cache-owned-chapters.tmp")
            runCatching {
                tempFile.writeText(merged.joinToString("\n") { (mangaId, chapterId) -> "$mangaId:$chapterId" })
                // renameTo() is not reliable on all Android filesystems when
                // the destination exists. Copy with overwrite as a fallback,
                // and never throw from cache maintenance into the UI process.
                if (!tempFile.renameTo(recordsFile)) {
                    tempFile.copyTo(recordsFile, overwrite = true)
                    tempFile.delete()
                }
                true
            }.getOrElse {
                tempFile.delete()
                false
            }
        }

    private fun readRecords(): List<Pair<Long, Long>> {
        if (!recordsFile.exists()) return emptyList()
        return recordsFile.useLines { lines ->
            lines.mapNotNull { line ->
                val split = line.split(':', limit = 2)
                val mangaId = split.getOrNull(0)?.toLongOrNull()
                val chapterId = split.getOrNull(1)?.toLongOrNull()
                if (mangaId != null && chapterId != null) mangaId to chapterId else null
            }.toList()
        }
    }

    private fun parseIds(value: String): List<Long> = value
        .split(',')
        .mapNotNull(String::toLongOrNull)
        .distinct()

    data class CacheResult(
        val titleCount: Int,
        val newlyQueuedChapterCount: Int,
    )

    private data class CachedTitle(
        val manga: Manga,
        val chapters: List<Chapter>,
    )

    private companion object {
        val RECORDS_LOCK = Any()
        const val TITLES_PER_DAY = 30
    }
}
