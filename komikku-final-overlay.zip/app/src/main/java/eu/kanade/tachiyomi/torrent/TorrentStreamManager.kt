package eu.kanade.tachiyomi.torrent

import android.content.Context
import eu.kanade.domain.manga.interactor.UpdateManga
import eu.kanade.tachiyomi.data.cache.CoverCache
import eu.kanade.tachiyomi.network.NetworkHelper
import eu.kanade.tachiyomi.source.online.TorrentSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.jsoup.Jsoup
import org.libtorrent4j.Priority
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentFlags
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import org.json.JSONArray
import org.json.JSONObject
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipFile
import kotlin.coroutines.cancellation.CancellationException

object TorrentImportControl {
    private const val PREFS = "torrent_import_controls"
    private const val PAUSED = "paused"
    private const val CANCELLED = "cancelled"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun isPaused(context: Context): Boolean = prefs(context).getBoolean(PAUSED, false)
    fun isCancelled(context: Context): Boolean = prefs(context).getBoolean(CANCELLED, false)
    fun reset(context: Context) = prefs(context).edit().putBoolean(PAUSED, false).putBoolean(CANCELLED, false).apply()
    fun pause(context: Context) = prefs(context).edit().putBoolean(PAUSED, true).apply()
    fun resume(context: Context) = prefs(context).edit().putBoolean(PAUSED, false).apply()
    fun cancel(context: Context) = prefs(context).edit().putBoolean(CANCELLED, true).putBoolean(PAUSED, false).apply()

    suspend fun awaitResume(context: Context) {
        while (isPaused(context) && !isCancelled(context)) delay(500)
    }
}

/**
 * Torrent-backed streaming coordinator. It never marks the complete torrent as wanted:
 * all files start at priority IGNORE, and only the CBZ/ZIP currently being read is selected.
 * The selected archive is temporarily cached and is eligible for eviction after the cache
 * limit is reached. No full-torrent prefetch or startup session is performed.
 */
class TorrentStreamManager(
    private val context: Context,
) {
    private companion object {
        const val METADATA_FILE = "torrent.metainfo"
        const val BOOKS_FILE = "torrent.books.json"
    }
    private val lock = Mutex()
    private val sessionLock = Any()
    private val catalogRestoreLock = Any()
    private val catalogs = ConcurrentHashMap<String, TorrentCatalog>()
    private val persistedBookIndexes = ConcurrentHashMap<String, List<TorrentBook>>()
    private val startedCatalogs = ConcurrentHashMap.newKeySet<String>()
    private val archiveLru = LinkedHashMap<String, File>(32, 0.75f, true)
    private val archiveLruLock = Any()
    private val archiveIndexes = ConcurrentHashMap<String, ArchiveIndex>()
    private val readyArchives = ConcurrentHashMap.newKeySet<String>()
    private val coverCache = CoverCache(context)
    private val coverPrefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val coverWarmQueued = ConcurrentHashMap.newKeySet<String>()
    private val coverWarmSemaphore = Semaphore(2)
    private val streamSemaphore = Semaphore(4)
    private val streamLocks = ConcurrentHashMap<String, Mutex>()
    private val libraryMangaIds = ConcurrentHashMap<String, Long>()
    private val libraryMappingPrefs = context.getSharedPreferences("torrent_library_mapping", Context.MODE_PRIVATE)
    private val cacheLimitBytes = 512L * 1024L * 1024L
    // Archive payloads remain evictable cache data; metainfo and the book index live in filesDir so
    // Android cache cleanup cannot make an imported library row unrecoverable days later.
    private val torrentRoot = File(context.cacheDir, "torrent_stream").apply { mkdirs() }
    private val catalogRoot = File(context.filesDir, "torrent_catalog").apply { mkdirs() }
    @Volatile
    private var session: SessionManager? = null

    data class TorrentBook(
        val key: String,
        val torrentHash: String,
        val fileIndex: Int,
        val path: String,
        val title: String,
        val artist: String?,
        val size: Long,
    )

    data class TorrentImportResult(
        val torrentHash: String,
        val torrentName: String,
        val books: List<TorrentBook>,
        val totalBytes: Long,
    )

    private data class ArchiveIndex(
        val pageNames: List<String>,
        val coverName: String,
    )

    private data class ZipEntryRange(
        val offset: Long,
        val length: Long,
    )

    private data class TorrentCatalog(
        val hash: String,
        val info: TorrentInfo,
        val books: List<TorrentBook>,
        val saveDirectory: File,
    )

    suspend fun importLink(input: String): TorrentImportResult = withContext(Dispatchers.IO) {
        val normalized = input.trim()
        require(normalized.isNotEmpty()) { "Enter a magnet, .torrent URL, or Sukebei/Nyaa detail URL." }
        lock.withLock {
            val torrentBytes = resolveMetainfo(normalized)
            val info = TorrentInfo(torrentBytes)
            require(info.isValid) { "The supplied link did not contain valid torrent metadata." }
            val hash = info.infoHash().toHex().lowercase(Locale.ROOT)
            val name = info.files().name().ifBlank { "Torrent $hash" }
            val saveDirectory = File(torrentRoot, hash).apply { mkdirs() }
            atomicWriteBytes(File(catalogDirectory(hash).apply { mkdirs() }, METADATA_FILE), torrentBytes)
            val books = buildBooks(hash, info)
            require(books.isNotEmpty()) { "No supported CBZ or ZIP doujin archives were found in this torrent." }
            writeBookIndex(hash, books)
            val catalog = TorrentCatalog(hash, info, books, saveDirectory)
            catalogs[hash] = catalog
            startSelectiveSession(catalog)
            TorrentImportResult(hash, name, books, info.totalSize())
        }
    }

    fun allBooks(): List<TorrentBook> {
        // Metadata browsing is deliberately independent of libtorrent startup. This keeps source
        // selection safe while still showing persisted Torrent books after an app restart.
        val persistedDirectories = buildList<File> {
            addAll(catalogRoot.listFiles().orEmpty().toList())
            addAll(torrentRoot.listFiles().orEmpty().toList())
        }
        val persisted = persistedDirectories
            .filter { directory -> directory.isDirectory }
            .flatMap { directory -> loadBookIndex(directory.name) }
        // Do not start cover downloads or native libtorrent work from this synchronous browse path.
        // Covers are warmed after import or fetched on demand by the cover pipeline.
        return (catalogs.values.flatMap { it.books } + persisted).distinctBy { it.key }
    }

    fun findBook(key: String): TorrentBook? {
        val hash = key.substringBefore('/')
        val catalog = catalogs[hash]
        return catalog?.books?.firstOrNull { it.key == key }
            ?: loadBookIndex(hash).firstOrNull { it.key == key }
            ?: restoreCatalog(hash)?.books?.firstOrNull { it.key == key }
    }

    fun registerLibraryManga(bookKey: String, mangaId: Long) {
        libraryMangaIds[bookKey] = mangaId
        libraryMappingPrefs.edit().putLong(bookKey, mangaId).apply()
    }

    private fun libraryMangaId(bookKey: String): Long? {
        libraryMangaIds[bookKey]?.let { return it }
        val stored = libraryMappingPrefs.getLong(bookKey, -1L)
        return stored.takeIf { it > 0L }?.also { libraryMangaIds[bookKey] = it }
    }

    suspend fun pageNames(bookKey: String): List<String> = withBookStream(bookKey) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        val archive = ensureArchive(book)
        archiveIndex(book, archive).pageNames
    }

    suspend fun readCover(bookKey: String): Pair<ByteArray, String> = withBookStream(bookKey) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        val archive = ensureArchive(book)
        val index = archiveIndex(book, archive)
        readEntryWithRetry(book, index.coverName)
    }

    suspend fun readPage(bookKey: String, entryName: String): Pair<ByteArray, String> = withBookStream(bookKey) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        readEntryWithRetry(book, entryName)
    }

    private suspend fun <T> withBookStream(bookKey: String, block: suspend () -> T): T {
        val bookLock = streamLocks.getOrPut(bookKey) { Mutex() }
        return streamSemaphore.withPermit {
            bookLock.withLock { block() }
        }
    }

    /**
     * Starts non-blocking cover warming after import. Covers are written to the normal persistent
     * library-cover cache, so the first image remains available even before the user opens a book.
     */
    fun prefetchCovers(
        books: List<TorrentBook>,
        onCoverReady: suspend (TorrentBook) -> Unit = {},
    ) {
        books.forEach { book ->
            if (!coverWarmQueued.add(book.key)) return@forEach
            coverPrefetchScope.launch {
                try {
                    coverWarmSemaphore.withPermit {
                        val coverFile = coverCache.getCoverFile(coverUrl(book.key))
                        if (coverFile != null) {
                            val mangaId = libraryMangaId(book.key)
                                ?: Injekt.get<tachiyomi.domain.manga.repository.MangaRepository>()
                                    .getMangaByUrlAndSourceId(book.key, TorrentSource.ID)
                                    ?.id
                                    ?.also { registerLibraryManga(book.key, it) }
                            val customFile = mangaId?.let { coverCache.getCustomCoverFile(it) }
                            val hasCover = (coverFile.exists() && coverFile.length() > 0L) ||
                                (customFile?.exists() == true && customFile.length() > 0L)
                            if (!hasCover) {
                                val (bytes, _) = readCover(book.key)
                                writeCoverAtomically(coverFile, bytes)
                                customFile?.let { if (!it.exists()) writeCoverAtomically(it, bytes) }
                                mangaId?.let { Injekt.get<UpdateManga>().awaitUpdateCoverLastModified(it) }
                            }
                            onCoverReady(book)
                        }
                    }
                } catch (error: Throwable) {
                    if (error is CancellationException) throw error
                    // A missing peer or malformed archive must not crash the library tab. The key
                    // is released so a later library refresh can retry the cover.
                } finally {
                    coverWarmQueued.remove(book.key)
                }
            }
        }
    }

    suspend fun pauseAll() = withContext(Dispatchers.IO) {
        catalogs.values.forEach { catalog -> findHandle(catalog)?.pause() }
    }

    suspend fun resumeAll() = withContext(Dispatchers.IO) {
        catalogs.values.forEach { catalog -> findHandle(catalog)?.resume() }
    }

    suspend fun clearTemporaryCache() = withContext(Dispatchers.IO) {
        synchronized(archiveLruLock) { archiveLru.clear() }
        torrentRoot.listFiles().orEmpty().forEach { it.deleteRecursively() }
    }

    private suspend fun resolveMetainfo(input: String): ByteArray {
        if (input.startsWith("magnet:", true)) {
            ensureSession()
            return requireNotNull(session!!.fetchMagnet(input, 45, torrentRoot)) {
                "Magnet metadata could not be resolved from the current peers/trackers."
            }
        }
        val response = Injekt.get<NetworkHelper>().client.newCall(Request.Builder().url(input).build()).execute()
        response.use {
            require(it.isSuccessful) { "Torrent link returned HTTP ${it.code}." }
            val bytes = it.body?.bytes() ?: error("Torrent link returned an empty response.")
            val contentType = it.header("Content-Type").orEmpty().lowercase(Locale.ROOT)
            val looksLikeHtml = contentType.contains("html") || input.contains("/view/", true)
            if (!looksLikeHtml && !input.endsWith(".html", true)) return bytes
            val document = Jsoup.parse(bytes.toString(Charsets.UTF_8), input)
            val magnet = document.selectFirst("a[href^=magnet:]")?.attr("href")
                ?.let { URLDecoder.decode(it, Charsets.UTF_8.name()) }
            if (magnet.isNullOrBlank()) {
                val id = Regex("/view/(\\d+)").find(input)?.groupValues?.getOrNull(1)
                val fallback = id?.let { "${input.substringBefore("/view/")}/download/$it.torrent" }
                if (fallback != null) return resolveMetainfo(fallback)
                error("No magnet or .torrent link was found on the supplied Nyaa/Sukebei page.")
            }
            ensureSession()
            return requireNotNull(session!!.fetchMagnet(magnet, 45, torrentRoot)) {
                "Magnet metadata could not be resolved from the supplied page."
            }
        }
    }

    private fun buildBooks(hash: String, info: TorrentInfo): List<TorrentBook> {
        val storage = info.files()
        return buildList {
            for (index in 0 until storage.numFiles()) {
                val path = storage.filePath(index)
                val lower = path.lowercase(Locale.ROOT)
                if (!lower.endsWith(".cbz") && !lower.endsWith(".zip")) continue
                if (storage.fileSize(index) <= 0L) continue
                val fileName = storage.fileName(index)
                val title = fileName.substringBeforeLast('.', fileName).trim().ifBlank { fileName }
                val artist = Regex("^\\[([^]]+)]").find(title)?.groupValues?.getOrNull(1)?.trim()
                add(
                    TorrentBook(
                        key = "$hash/$index",
                        torrentHash = hash,
                        fileIndex = index,
                        path = path,
                        title = title,
                        artist = artist,
                        size = storage.fileSize(index),
                    ),
                )
            }
        }
    }

    private fun catalogDirectory(hash: String): File = File(catalogRoot, hash)

    private fun atomicWrite(file: File, text: String) {
        atomicWriteBytes(file, text.toByteArray(Charsets.UTF_8))
    }

    private fun atomicWriteBytes(file: File, bytes: ByteArray) {
        file.parentFile?.mkdirs()
        val temporary = File(file.parentFile, "${file.name}.tmp")
        temporary.writeBytes(bytes)
        if (!temporary.renameTo(file)) {
            temporary.delete()
            error("Could not persist Torrent catalog metadata.")
        }
    }

    private fun writeBookIndex(hash: String, books: List<TorrentBook>) {
        val index = JSONArray()
        books.forEach { book ->
            index.put(JSONObject().apply {
                put("key", book.key)
                put("hash", book.torrentHash)
                put("fileIndex", book.fileIndex)
                put("path", book.path)
                put("title", book.title)
                put("artist", book.artist ?: JSONObject.NULL)
                put("size", book.size)
            })
        }
        val file = File(catalogDirectory(hash).apply { mkdirs() }, BOOKS_FILE)
        atomicWrite(file, index.toString())
        persistedBookIndexes[hash] = books
    }

    private fun loadBookIndex(hash: String): List<TorrentBook> {
        persistedBookIndexes[hash]?.let { return it }
        val file = listOf(
            File(catalogDirectory(hash), BOOKS_FILE),
            File(torrentRoot, "$hash/$BOOKS_FILE"),
        ).firstOrNull { it.isFile } ?: return emptyList()
        return runCatching {
            val json = JSONArray(file.readText())
            buildList {
                for (index in 0 until json.length()) {
                    val item = json.getJSONObject(index)
                    add(
                        TorrentBook(
                            key = item.getString("key"),
                            torrentHash = item.getString("hash"),
                            fileIndex = item.getInt("fileIndex"),
                            path = item.getString("path"),
                            title = item.getString("title"),
                            artist = item.optString("artist").takeIf { it.isNotBlank() && it != "null" },
                            size = item.getLong("size"),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList()).also { persistedBookIndexes[hash] = it }
    }

    private fun restoreCatalog(hash: String): TorrentCatalog? = synchronized(catalogRestoreLock) {
        catalogs[hash]?.let { return@synchronized it }
        val legacyDirectory = File(torrentRoot, hash)
        val metadata = listOf(
            File(catalogDirectory(hash), METADATA_FILE),
            File(legacyDirectory, METADATA_FILE),
        ).firstOrNull { it.isFile && it.length() > 0L } ?: return@synchronized null
        runCatching {
            val info = TorrentInfo(metadata.readBytes())
            require(info.isValid) { "Persisted torrent metadata is invalid." }
            val books = loadBookIndex(hash).ifEmpty { buildBooks(hash, info) }
            require(books.isNotEmpty()) { "Persisted torrent contains no supported archives." }
            val durableDirectory = catalogDirectory(hash).apply { mkdirs() }
            if (metadata.parentFile != durableDirectory) {
                atomicWriteBytes(File(durableDirectory, METADATA_FILE), metadata.readBytes())
                writeBookIndex(hash, books)
            }
            TorrentCatalog(hash, info, books, legacyDirectory).also { catalog ->
                catalogs[hash] = catalog
            }
        }.getOrNull()
    }

    private fun startSelectiveSession(catalog: TorrentCatalog) {
        if (!startedCatalogs.add(catalog.hash)) return
        val priorities = Priority.array(Priority.IGNORE, catalog.info.files().numFiles())
        ensureSessionBlocking().download(
            catalog.info,
            catalog.saveDirectory,
            null,
            priorities,
            null,
            TorrentFlags.AUTO_MANAGED.or_(TorrentFlags.UPDATE_SUBSCRIBE),
        )
    }

    private suspend fun ensureArchive(book: TorrentBook): File {
        val catalog = catalogs[book.torrentHash]
            ?: restoreCatalog(book.torrentHash)
            ?: error("Torrent session metadata is unavailable. Re-import the torrent to restore its session.")
        val target = File(catalog.info.files().filePath(book.fileIndex, catalog.saveDirectory.absolutePath))
        synchronized(archiveLruLock) {
            archiveLru[book.key] = target
        }
        if (readyArchives.contains(book.key) && target.exists()) return target

        startSelectiveSession(catalog)
        val handle = waitForHandle(catalog)
        prioritizeArchiveMetadata(handle, catalog, book)
        handle.resume()
        var available = false
        var lastError: Throwable? = null
        // First try the metadata windows only. This is fast when the central directory and the
        // beginning of the archive are available, and it avoids waiting for every page body.
        for (attempt in 0 until 240) {
            TorrentImportControl.awaitResume(context)
            check(!TorrentImportControl.isCancelled(context)) { "Torrent streaming was canceled." }
            if (target.exists()) {
                try {
                    archiveIndex(book, target)
                    available = true
                } catch (error: Throwable) {
                    if (error is CancellationException) throw error
                    lastError = error
                }
                if (available) break
            }
            delay(250)
        }
        // Some CBZ files have a central directory layout that cannot be validated from sparse
        // metadata windows. Fall back to the previously working, safe complete-file path rather
        // than leaving the reader blocked indefinitely.
        if (!available) {
            handle.filePriority(book.fileIndex, Priority.TOP_PRIORITY)
            handle.resume()
            try {
                waitForFileComplete(handle, book)
                archiveIndex(book, target)
                available = true
            } catch (error: Throwable) {
                if (error is CancellationException) throw error
                lastError = error
            }
        }
        handle.pause()
        require(available) {
            if (target.exists() && target.length() >= book.size) {
                "The selected file is not a valid ZIP/CBZ archive. The torrent may label a non-ZIP archive as CBZ/ZIP."
            } else {
                lastError?.message ?: "The selected torrent archive is not available yet. Peers may be offline or the torrent may be incomplete."
            }
        }
        readyArchives += book.key
        pruneCache(keepKey = book.key)
        return target
    }

    private fun archiveIndex(book: TorrentBook, archive: File? = null): ArchiveIndex {
        archiveIndexes[book.key]?.let { return it }
        val file = archive ?: File(
            requireNotNull(catalogs[book.torrentHash]).info.files().filePath(
                book.fileIndex,
                requireNotNull(catalogs[book.torrentHash]).saveDirectory.absolutePath,
            ),
        )
        return ZipFile(file).use { zip ->
            val names = zip.entries().asSequence()
                .filter { !it.isDirectory && isImage(it.name) }
                .map { it.name }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })
                .toList()
                .also { require(it.isNotEmpty()) { "The selected archive contains no readable image pages." } }
            ArchiveIndex(names, names.first())
        }.also { archiveIndexes[book.key] = it }
    }

    private suspend fun readEntryWithRetry(book: TorrentBook, entryName: String): Pair<ByteArray, String> {
        var lastError: Throwable? = null
        repeat(2) { attempt ->
            try {
                val archive = ensureEntryAvailable(book, entryName)
                return ZipFile(archive).use { zip ->
                    val entry = zip.getEntry(entryName) ?: error("Torrent page is not present in the archive.")
                    zip.getInputStream(entry).use { it.readBytes() } to imageType(entryName)
                }
            } catch (error: Throwable) {
                if (error is CancellationException) throw error
                lastError = error
                readyArchives.remove(book.key)
                archiveIndexes.remove(book.key)
                if (attempt == 0) {
                    catalogs[book.torrentHash]?.let { findHandle(it)?.forceRecheck() }
                    delay(250)
                }
            }
        }
        throw lastError ?: error("Unable to read the selected Torrent page.")
    }

    private suspend fun ensureEntryAvailable(book: TorrentBook, entryName: String): File {
        val archive = ensureArchive(book)
        val catalog = requireNotNull(catalogs[book.torrentHash])
        val handle = waitForHandle(catalog)
        val range = zipEntryRange(archive, entryName)
        if (range == null) {
            // ZIP64 or an unusual archive layout: fall back to the safe whole-file path.
            handle.filePriority(book.fileIndex, Priority.TOP_PRIORITY)
            handle.resume()
            waitForFileComplete(handle, book)
            handle.pause()
            return archive
        }

        // Do not leave the entire CBZ at high priority: only the requested entry range should
        // remain wanted, while the active session stays resumed for faster adjacent pages.
        handle.filePriority(book.fileIndex, Priority.IGNORE)
        val firstPiece = catalog.info.mapFile(book.fileIndex, range.offset, 1).piece()
        val lastPiece = catalog.info.mapFile(
            book.fileIndex,
            range.offset + range.length - 1,
            1,
        ).piece()
        for (piece in firstPiece..lastPiece) {
            handle.piecePriority(piece, Priority.TOP_PRIORITY)
        }
        handle.resume()
        var ready = false
        for (attempt in 0 until 1440) {
            TorrentImportControl.awaitResume(context)
            check(!TorrentImportControl.isCancelled(context)) { "Torrent streaming was canceled." }
            if ((firstPiece..lastPiece).all(handle::havePiece)) {
                ready = true
                break
            }
            delay(100)
        }
        if (!ready) handle.pause()
        require(ready) { "The selected Torrent page is not available yet. Peers may be offline or the torrent may be incomplete." }
        return archive
    }

    private suspend fun waitForFileComplete(handle: TorrentHandle, book: TorrentBook) {
        repeat(1440) {
            TorrentImportControl.awaitResume(context)
            check(!TorrentImportControl.isCancelled(context)) { "Torrent streaming was canceled." }
            val progress = runCatching { handle.fileProgress().getOrNull(book.fileIndex) ?: 0L }.getOrDefault(0L)
            if (progress >= book.size) return
            delay(250)
        }
        error("The selected Torrent archive is not available yet. Peers may be offline or the torrent may be incomplete.")
    }

    private fun prioritizeArchiveMetadata(handle: TorrentHandle, catalog: TorrentCatalog, book: TorrentBook) {
        val pieceLength = catalog.info.pieceLength().toLong().coerceAtLeast(1L)
        val firstPiece = (catalog.info.files().fileOffset(book.fileIndex) / pieceLength).toInt()
        val lastPiece = ((catalog.info.files().fileOffset(book.fileIndex) + book.size - 1L) / pieceLength).toInt()
        val firstWindowEnd = minOf(lastPiece, firstPiece + 31)
        val lastWindowStart = maxOf(firstPiece, lastPiece - 255)
        for (piece in firstPiece..firstWindowEnd) handle.piecePriority(piece, Priority.TOP_PRIORITY)
        for (piece in lastWindowStart..lastPiece) handle.piecePriority(piece, Priority.TOP_PRIORITY)
    }

    private fun zipEntryRange(file: File, entryName: String): ZipEntryRange? = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            val scanLength = minOf(raf.length(), 65_557L)
            val scanStart = raf.length() - scanLength
            val tail = ByteArray(scanLength.toInt())
            raf.seek(scanStart)
            raf.readFully(tail)
            val eocd = findSignatureFromEnd(tail, 0x06054b50L)
            if (eocd < 0) return@runCatching null
            val entries = readLeShort(tail, eocd + 10)
            val directorySize = readLeInt(tail, eocd + 12)
            val directoryOffset = readLeInt(tail, eocd + 16)
            if (entries == 0xFFFF || directorySize == 0xFFFFFFFFL || directoryOffset == 0xFFFFFFFFL) return@runCatching null
            raf.seek(directoryOffset)
            for (entryIndex in 0 until entries) {
                if (raf.readIntLE() != 0x02014b50) return@runCatching null
                raf.skipBytes(2) // version made by
                raf.skipBytes(2) // version needed
                val flags = raf.readUnsignedShortLE()
                raf.skipBytes(2) // compression method
                raf.skipBytes(4) // modification time and date
                raf.skipBytes(4) // CRC-32
                val compressedSize = raf.readUnsignedIntLE()
                raf.skipBytes(4) // uncompressed size
                val nameLength = raf.readUnsignedShortLE()
                val extraLength = raf.readUnsignedShortLE()
                val commentLength = raf.readUnsignedShortLE()
                raf.skipBytes(8)
                val localOffset = raf.readUnsignedIntLE()
                val nameBytes = ByteArray(nameLength)
                raf.readFully(nameBytes)
                val name = String(nameBytes, if ((flags and 0x800) != 0) Charsets.UTF_8 else Charsets.ISO_8859_1)
                raf.skipBytes(extraLength + commentLength)
                if (name != entryName || compressedSize == 0xFFFFFFFFL || localOffset == 0xFFFFFFFFL) continue
                raf.seek(localOffset + 26)
                val localNameLength = raf.readUnsignedShortLE()
                val localExtraLength = raf.readUnsignedShortLE()
                return@runCatching ZipEntryRange(
                    localOffset,
                    30L + localNameLength + localExtraLength + compressedSize,
                )
            }
            null
        }
    }.getOrNull()?.takeIf { it.length > 0L }

    private fun findSignatureFromEnd(bytes: ByteArray, signature: Long): Int {
        for (index in bytes.size - 4 downTo 0) {
            if (readLeInt(bytes, index) == signature) return index
        }
        return -1
    }

    private fun readLeShort(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun readLeInt(bytes: ByteArray, offset: Int): Long =
        (readLeShort(bytes, offset).toLong() and 0xFFFF) or ((readLeShort(bytes, offset + 2).toLong() and 0xFFFF) shl 16)

    private fun RandomAccessFile.readIntLE(): Int = readUnsignedIntLE().toInt()
    private fun RandomAccessFile.readUnsignedShortLE(): Int = readLeShort(byteArrayOf(readByte(), readByte()), 0)
    private fun RandomAccessFile.readUnsignedIntLE(): Long {
        val bytes = ByteArray(4)
        readFully(bytes)
        return readLeInt(bytes, 0)
    }

    private fun writeCoverAtomically(target: File, bytes: ByteArray) {
        target.parentFile?.mkdirs()
        val temporary = File(target.parentFile, "${target.name}.torrent.tmp")
        temporary.outputStream().use { it.write(bytes) }
        if (!temporary.renameTo(target)) {
            target.outputStream().use { it.write(bytes) }
            temporary.delete()
        }
    }

    private fun isReadableArchive(file: File): Boolean = runCatching {
        if (!file.exists() || file.length() < 22L) return@runCatching false
        ZipFile(file).use { zip ->
            zip.entries().asSequence().any { !it.isDirectory && isImage(it.name) }
        }
    }.getOrDefault(false)

    private fun coverUrl(bookKey: String): String = "https://torrent.invalid/cover/$bookKey"

    private suspend fun waitForHandle(catalog: TorrentCatalog): TorrentHandle = withContext(Dispatchers.IO) {
        repeat(90) {
            findHandle(catalog)?.let { return@withContext it }
            delay(500)
        }
        error("Torrent session did not start.")
    }

    private fun findHandle(catalog: TorrentCatalog): TorrentHandle? =
        ensureSessionBlocking().find(catalog.info.infoHash())

    private fun ensureSession(): SessionManager {
        return ensureSessionBlocking()
    }

    private fun ensureSessionBlocking(): SessionManager = synchronized(sessionLock) {
        session?.let { return@synchronized it }
        SessionManager(false).also {
            it.start()
            session = it
        }
    }

    private fun pruneCache(keepKey: String? = null) {
        synchronized(archiveLruLock) {
            var total = archiveLru.values.distinct().filter(File::exists).sumOf(File::length)
            val iterator = archiveLru.entries.iterator()
            while (total > cacheLimitBytes && iterator.hasNext()) {
                val entry = iterator.next()
                if (entry.key == keepKey) continue
                val file = entry.value
                if (file.exists()) total -= file.length()
                file.delete()
                iterator.remove()
            }
        }
    }

    private fun imageType(name: String): String = when {
        name.endsWith(".png", true) -> "image/png"
        name.endsWith(".webp", true) -> "image/webp"
        name.endsWith(".gif", true) -> "image/gif"
        else -> "image/jpeg"
    }

    private fun isImage(name: String): Boolean = name.lowercase(Locale.ROOT).let {
        it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") ||
            it.endsWith(".webp") || it.endsWith(".gif")
    }
}
