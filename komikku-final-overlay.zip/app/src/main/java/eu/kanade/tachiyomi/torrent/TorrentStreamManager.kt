package eu.kanade.tachiyomi.torrent

import android.content.Context
import eu.kanade.tachiyomi.network.NetworkHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.jsoup.Jsoup
import org.libtorrent4j.Priority
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentFlags
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import org.libtorrent4j.swig.remove_flags_t
import org.json.JSONArray
import org.json.JSONObject
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.LinkedHashMap
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream
import kotlin.coroutines.cancellation.CancellationException

object TorrentImportControl {
    private const val PREFS = "torrent_import_controls"
    private const val PAUSED = "paused"
    private const val CANCELLED = "cancelled"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun isPaused(context: Context): Boolean = prefs(context).getBoolean(PAUSED, false)
    fun isCancelled(context: Context): Boolean = prefs(context).getBoolean(CANCELLED, false)
    fun reset(context: Context) = prefs(context).edit().putBoolean(PAUSED, false).putBoolean(CANCELLED, false).apply()
    fun pause(context: Context) = prefs(context).edit().putBoolean(PAUSED, true).apply()
    fun resume(context: Context) = prefs(context).edit().putBoolean(PAUSED, false).apply()
    fun cancel(context: Context) = prefs(context).edit().putBoolean(CANCELLED, true).putBoolean(PAUSED, false).apply()

    suspend fun awaitResume(context: Context) {
        while (isPaused(context) && !isCancelled(context)) delay(250)
    }
}

/**
 * Selective Torrent reader for CBZ/ZIP files.
 *
 * Catalog metadata is retained separately from the transient torrent workspace. A cover or reader
 * request may retrieve only the ZIP directory, local header and requested image's torrent pieces.
 * The active torrent is removed and its workspace deleted before the request returns. There is no
 * full-file fallback and no list-wide cover prefetch path in this manager.
 */
class TorrentStreamManager(
    private val context: Context,
) {
    private companion object {
        const val METADATA_FILE = "torrent.metainfo"
        const val BOOKS_FILE = "torrent.books.json"
        const val ZIP_EOCD_SCAN_BYTES = 65_557L
        const val LOCAL_HEADER_SCAN_BYTES = 65_536L
        const val MAX_ZIP_DIRECTORY_BYTES = 4L * 1024L * 1024L
        const val MAX_ZIP_ENTRIES = 10_000
        const val MAX_COMPRESSED_PAGE_BYTES = 24L * 1024L * 1024L
        const val MAX_UNCOMPRESSED_PAGE_BYTES = 48L * 1024L * 1024L
        const val TEMPORARY_PIECE_BUDGET_BYTES = 64L * 1024L * 1024L
        // A cold mobile torrent connection needs time to announce, connect and be unchoked before
        // its first ZIP directory/page piece can arrive. This is deliberately finite, but cannot
        // honestly be a five-second guarantee for an arbitrary public swarm.
        const val REQUEST_DEADLINE_MILLIS = 45_000L
        const val REQUEST_FAILURE_COOLDOWN_MILLIS = 3_000L
        const val INDEX_CACHE_ENTRIES = 12
    }

    private val lock = Mutex()
    private val sessionLock = Any()
    private val catalogRestoreLock = Any()
    private val catalogs = ConcurrentHashMap<String, TorrentCatalog>()
    private val persistedBookIndexes = ConcurrentHashMap<String, List<TorrentBook>>()
    private val startedCatalogs = ConcurrentHashMap.newKeySet<String>()
    private val archiveIndexes = LinkedHashMap<String, ArchiveIndex>(INDEX_CACHE_ENTRIES, 0.75f, true)
    private val archiveIndexLock = Any()
    private val streamLocks = ConcurrentHashMap<String, Mutex>()
    private val streamSemaphore = Semaphore(1)
    private val retryAfterMillis = ConcurrentHashMap<String, Long>()
    private val activeStreamLock = Any()
    private var activeStream: ActiveStream? = null
    private val catalogRoot = File(context.filesDir, "torrent_catalog").apply { mkdirs() }
    private val torrentRoot = File(context.cacheDir, "torrent_stream").apply { mkdirs() }
    private val metadataScratch = File(context.cacheDir, "torrent_metadata").apply { mkdirs() }

    @Volatile
    private var session: SessionManager? = null

    data class TorrentBook(
        val key: String,
        val torrentHash: String,
        val fileIndex: Int,
        val path: String,
        val title: String,
        val artist: String?,
        val size: Long,
    )

    data class TorrentImportResult(
        val torrentHash: String,
        val torrentName: String,
        val books: List<TorrentBook>,
        val totalBytes: Long,
    )

    private data class ZipEntryData(
        val name: String,
        val flags: Int,
        val compressionMethod: Int,
        val compressedSize: Long,
        val uncompressedSize: Long,
        val localHeaderOffset: Long,
    )

    private data class ArchiveIndex(
        val pageNames: List<String>,
        val coverName: String,
        val entries: Map<String, ZipEntryData>,
    )

    private data class EndOfCentralDirectory(
        val entryCount: Int,
        val directoryOffset: Long,
        val directorySize: Long,
    )

    private data class TorrentCatalog(
        val hash: String,
        val info: TorrentInfo,
        val books: List<TorrentBook>,
        val saveDirectory: File,
    )

    private data class ActiveStream(
        val bookKey: String,
        val catalog: TorrentCatalog,
        val handle: TorrentHandle,
        val archive: File,
        val requestedPieces: MutableSet<Int> = linkedSetOf(),
        val deadlineNanos: Long = System.nanoTime() + REQUEST_DEADLINE_MILLIS * 1_000_000L,
    )

    suspend fun importLink(input: String): TorrentImportResult = withContext(kotlinx.coroutines.Dispatchers.IO) {
        val normalized = input.trim()
        require(normalized.isNotEmpty()) { "Enter a magnet, .torrent URL, or Sukebei/Nyaa detail URL." }
        lock.withLock {
            val torrentBytes = resolveMetainfo(normalized)
            val info = TorrentInfo(torrentBytes)
            require(info.isValid) { "The supplied link did not contain valid torrent metadata." }
            val hash = info.infoHash().toHex().lowercase(Locale.ROOT)
            val name = info.files().name().ifBlank { "Torrent $hash" }
            val books = buildBooks(hash, info)
            require(books.isNotEmpty()) { "No supported CBZ or ZIP doujin archives were found in this torrent." }

            val metadataDirectory = catalogDirectory(hash).apply { mkdirs() }
            File(metadataDirectory, METADATA_FILE).writeBytes(torrentBytes)
            writeBookIndex(hash, books)
            val catalog = TorrentCatalog(hash, info, books, File(torrentRoot, hash))
            catalogs[hash] = catalog

            // Deliberately do not create a libtorrent handle here. A large catalog import must be
            // metadata-only and cannot allocate archive files, priority windows or cover jobs.
            TorrentImportResult(hash, name, books, info.totalSize())
        }
    }

    fun allBooks(): List<TorrentBook> {
        // Synchronous source browsing must stay metadata-only. It never starts libtorrent or a
        // cover transfer, which keeps the Library source tabs stable for large Torrent catalogs.
        migrateLegacyCatalogs()
        val persisted = catalogDirectories().flatMap { loadBookIndex(it.name) }
        return (catalogs.values.flatMap { it.books } + persisted).distinctBy { it.key }
    }

    fun findBook(key: String): TorrentBook? {
        val hash = key.substringBefore('/')
        return catalogs[hash]?.books?.firstOrNull { it.key == key }
            ?: loadBookIndex(hash).firstOrNull { it.key == key }
            ?: restoreCatalog(hash)?.books?.firstOrNull { it.key == key }
    }

    /** Kept for importer compatibility; Torrent covers are no longer written to a device cache. */
    fun registerLibraryManga(bookKey: String, mangaId: Long) = Unit

    suspend fun pageNames(bookKey: String): List<String> = withBookStream(bookKey) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        ensureArchiveIndex(book).pageNames
    }

    suspend fun readCover(bookKey: String): Pair<ByteArray, String> = withBookStream(bookKey) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        val index = ensureArchiveIndex(book)
        readEntry(book, index.coverName)
    }

    suspend fun readPage(bookKey: String, entryName: String): Pair<ByteArray, String> = withBookStream(bookKey) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        readEntry(book, entryName)
    }

    private suspend fun <T> withBookStream(bookKey: String, block: suspend () -> T): T {
        val bookLock = streamLocks.getOrPut(bookKey) { Mutex() }
        return streamSemaphore.withPermit {
            bookLock.withLock {
                try {
                    val retryAfter = retryAfterMillis[bookKey] ?: 0L
                    require(System.currentTimeMillis() >= retryAfter) {
                        "Torrent data is temporarily unavailable. Retry this book in a few seconds; no archive was saved."
                    }
                    block().also { retryAfterMillis.remove(bookKey) }
                } catch (error: Throwable) {
                    if (error !is CancellationException) {
                        retryAfterMillis[bookKey] = System.currentTimeMillis() + REQUEST_FAILURE_COOLDOWN_MILLIS
                    }
                    throw error
                } finally {
                    // The response has already been copied to memory by this point. Removing the
                    // torrent and its directory prevents cover/page reads from accumulating.
                    releaseActiveStream(bookKey)
                }
            }
        }
    }

    suspend fun pauseAll() = withContext(kotlinx.coroutines.Dispatchers.IO) {
        session?.pause()
    }

    suspend fun resumeAll() = withContext(kotlinx.coroutines.Dispatchers.IO) {
        session?.resume()
    }

    suspend fun clearTemporaryCache() = withContext(kotlinx.coroutines.Dispatchers.IO) {
        migrateLegacyCatalogs()
        releaseActiveStream()
        torrentRoot.listFiles().orEmpty().forEach { it.deleteRecursively() }
        metadataScratch.listFiles().orEmpty().forEach { it.deleteRecursively() }
        synchronized(archiveIndexLock) { archiveIndexes.clear() }
    }

    private suspend fun resolveMetainfo(input: String): ByteArray {
        if (input.startsWith("magnet:", true)) {
            return fetchMagnetMetainfo(input)
        }
        val response = Injekt.get<NetworkHelper>().client.newCall(Request.Builder().url(input).build()).execute()
        response.use {
            require(it.isSuccessful) { "Torrent link returned HTTP ${it.code}." }
            val bytes = it.body?.bytes() ?: error("Torrent link returned an empty response.")
            val contentType = it.header("Content-Type").orEmpty().lowercase(Locale.ROOT)
            val looksLikeHtml = contentType.contains("html") || input.contains("/view/", true)
            if (!looksLikeHtml && !input.endsWith(".html", true)) return bytes
            val document = Jsoup.parse(bytes.toString(Charsets.UTF_8), input)
            val magnet = document.selectFirst("a[href^=magnet:]")?.attr("href")
                ?.let { URLDecoder.decode(it, Charsets.UTF_8.name()) }
            if (magnet.isNullOrBlank()) {
                val id = Regex("/view/(\\d+)").find(input)?.groupValues?.getOrNull(1)
                val fallback = id?.let { "${input.substringBefore("/view/")}/download/$it.torrent" }
                if (fallback != null) return resolveMetainfo(fallback)
                error("No magnet or .torrent link was found on the supplied Nyaa/Sukebei page.")
            }
            return fetchMagnetMetainfo(magnet)
        }
    }

    private fun fetchMagnetMetainfo(magnet: String): ByteArray = try {
        ensureSession().fetchMagnet(magnet, 45, metadataScratch)
            ?: error("Magnet metadata could not be resolved from the current peers/trackers.")
    } finally {
        metadataScratch.listFiles().orEmpty().forEach { it.deleteRecursively() }
    }

    private fun buildBooks(hash: String, info: TorrentInfo): List<TorrentBook> {
        val storage = info.files()
        return buildList {
            for (index in 0 until storage.numFiles()) {
                val path = storage.filePath(index)
                val lower = path.lowercase(Locale.ROOT)
                if (!lower.endsWith(".cbz") && !lower.endsWith(".zip")) continue
                if (storage.fileSize(index) <= 0L) continue
                val fileName = storage.fileName(index)
                val title = fileName.substringBeforeLast('.', fileName).trim().ifBlank { fileName }
                val artist = Regex("^\\[([^]]+)]").find(title)?.groupValues?.getOrNull(1)?.trim()
                add(
                    TorrentBook(
                        key = "$hash/$index",
                        torrentHash = hash,
                        fileIndex = index,
                        path = path,
                        title = title,
                        artist = artist,
                        size = storage.fileSize(index),
                    ),
                )
            }
        }
    }

    private fun catalogDirectory(hash: String): File = File(catalogRoot, hash)
    private fun legacyCatalogDirectory(hash: String): File = File(torrentRoot, hash)

    private fun catalogDirectories(): List<File> =
        (catalogRoot.listFiles().orEmpty().filter(File::isDirectory) +
            torrentRoot.listFiles().orEmpty().filter(File::isDirectory))
            .distinctBy { it.name }

    private fun writeBookIndex(hash: String, books: List<TorrentBook>) {
        val index = JSONArray()
        books.forEach { book ->
            index.put(JSONObject().apply {
                put("key", book.key)
                put("hash", book.torrentHash)
                put("fileIndex", book.fileIndex)
                put("path", book.path)
                put("title", book.title)
                put("artist", book.artist ?: JSONObject.NULL)
                put("size", book.size)
            })
        }
        val file = File(catalogDirectory(hash).apply { mkdirs() }, BOOKS_FILE)
        file.writeText(index.toString())
        persistedBookIndexes[hash] = books
    }

    private fun loadBookIndex(hash: String): List<TorrentBook> {
        persistedBookIndexes[hash]?.let { return it }
        val file = listOf(
            File(catalogDirectory(hash), BOOKS_FILE),
            File(legacyCatalogDirectory(hash), BOOKS_FILE),
        ).firstOrNull { it.isFile } ?: return emptyList()
        return runCatching {
            val json = JSONArray(file.readText())
            buildList {
                for (index in 0 until json.length()) {
                    val item = json.getJSONObject(index)
                    add(
                        TorrentBook(
                            key = item.getString("key"),
                            torrentHash = item.getString("hash"),
                            fileIndex = item.getInt("fileIndex"),
                            path = item.getString("path"),
                            title = item.getString("title"),
                            artist = item.optString("artist").takeIf { it.isNotBlank() && it != "null" },
                            size = item.getLong("size"),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList()).also { persistedBookIndexes[hash] = it }
    }

    private fun restoreCatalog(hash: String): TorrentCatalog? = synchronized(catalogRestoreLock) {
        catalogs[hash]?.let { return@synchronized it }
        val metadata = listOf(
            File(catalogDirectory(hash), METADATA_FILE),
            File(legacyCatalogDirectory(hash), METADATA_FILE),
        ).firstOrNull { it.isFile && it.length() > 0L } ?: return@synchronized null
        runCatching {
            val info = TorrentInfo(metadata.readBytes())
            require(info.isValid) { "Persisted torrent metadata is invalid." }
            val books = loadBookIndex(hash).ifEmpty { buildBooks(hash, info) }
            require(books.isNotEmpty()) { "Persisted torrent contains no supported archives." }
            TorrentCatalog(hash, info, books, File(torrentRoot, hash)).also { catalog ->
                catalogs[hash] = catalog
            }
        }.getOrNull()
    }

    private fun migrateLegacyCatalogs() {
        torrentRoot.listFiles().orEmpty().filter(File::isDirectory).forEach { directory ->
            migrateLegacyCatalog(directory.name)
        }
    }

    private fun migrateLegacyCatalog(hash: String) {
        val legacy = legacyCatalogDirectory(hash)
        val destination = catalogDirectory(hash)
        if (!legacy.isDirectory) return
        val oldMetadata = File(legacy, METADATA_FILE)
        val oldBooks = File(legacy, BOOKS_FILE)
        if (oldMetadata.isFile && oldBooks.isFile) {
            destination.mkdirs()
            oldMetadata.copyTo(File(destination, METADATA_FILE), overwrite = false)
            oldBooks.copyTo(File(destination, BOOKS_FILE), overwrite = false)
        }
        // A directory from the previous implementation may contain whole CBZ/ZIP files or sparse
        // payloads. Once its small catalog copies are safe in filesDir, remove every legacy byte.
        if (File(destination, METADATA_FILE).isFile && File(destination, BOOKS_FILE).isFile) {
            legacy.deleteRecursively()
        }
    }

    private suspend fun ensureArchiveIndex(book: TorrentBook): ArchiveIndex {
        cachedArchiveIndex(book.key)?.let { return it }
        val active = openActiveStream(book)
        val eocd = ensureCentralDirectory(active, book)
        val index = parseArchiveIndex(book, active.archive, eocd)
        cacheArchiveIndex(book.key, index)
        return index
    }

    private suspend fun readEntry(book: TorrentBook, entryName: String): Pair<ByteArray, String> {
        val index = ensureArchiveIndex(book)
        val entry = index.entries[entryName] ?: error("Torrent page is not present in the archive.")
        val active = openActiveStream(book)
        val payload = readSelectedEntry(active, book, entry)
        return payload to imageType(entry.name)
    }

    private suspend fun openActiveStream(book: TorrentBook): ActiveStream {
        synchronized(activeStreamLock) {
            activeStream?.takeIf { it.bookKey == book.key }?.let { return it }
        }
        releaseActiveStream()
        val catalog = catalogs[book.torrentHash]
            ?: restoreCatalog(book.torrentHash)
            ?: error("Torrent session metadata is unavailable. Re-import the torrent to restore its session.")
        migrateLegacyCatalog(catalog.hash)
        startSelectiveSession(catalog)
        val handle = waitForHandle(catalog)
        // New downloads are auto-managed by libtorrent by default. A short-lived interactive
        // request must opt out of that queue, otherwise it can remain paused until the request
        // window expires without contacting any peers.
        handle.unsetFlags(TorrentFlags.AUTO_MANAGED)
        handle.queuePositionTop()
        runCatching { handle.forceReannounce() }
        handle.resume()
        val archive = File(catalog.info.files().filePath(book.fileIndex, catalog.saveDirectory.absolutePath))
        return ActiveStream(book.key, catalog, handle, archive).also { active ->
            synchronized(activeStreamLock) { activeStream = active }
        }
    }

    private fun startSelectiveSession(catalog: TorrentCatalog) {
        val manager = ensureSessionBlocking()
        if (manager.find(catalog.info.infoHash()) != null) {
            startedCatalogs += catalog.hash
            return
        }
        catalog.saveDirectory.mkdirs()
        val priorities = Priority.array(Priority.IGNORE, catalog.info.files().numFiles())
        manager.download(
            catalog.info,
            catalog.saveDirectory,
            null,
            priorities,
            null,
            TorrentFlags.AUTO_MANAGED.or_(TorrentFlags.UPDATE_SUBSCRIBE),
        )
        startedCatalogs += catalog.hash
    }

    private suspend fun ensureCentralDirectory(active: ActiveStream, book: TorrentBook): EndOfCentralDirectory {
        val tailLength = minOf(book.size, ZIP_EOCD_SCAN_BYTES)
        val tailOffset = book.size - tailLength
        requestRange(active, book, tailOffset, tailLength, "ZIP directory")
        val eocd = parseEndOfCentralDirectory(book, active.archive)
        require(eocd.directorySize in 1..MAX_ZIP_DIRECTORY_BYTES) {
            "This CBZ/ZIP directory is too large for low-storage streaming. Open a different archive."
        }
        requestRange(active, book, eocd.directoryOffset, eocd.directorySize, "ZIP directory")
        return eocd
    }

    private fun parseEndOfCentralDirectory(book: TorrentBook, archive: File): EndOfCentralDirectory {
        require(archive.isFile) { "Torrent ZIP directory has not arrived yet." }
        RandomAccessFile(archive, "r").use { raf ->
            val length = raf.length()
            val scanLength = minOf(length, ZIP_EOCD_SCAN_BYTES).toInt()
            require(scanLength >= 22) { "The selected archive does not contain a readable ZIP directory." }
            val scanStart = length - scanLength
            val tail = ByteArray(scanLength)
            raf.seek(scanStart)
            raf.readFully(tail)
            val eocd = findSignatureFromEnd(tail, 0x06054b50L)
            require(eocd >= 0) { "This ZIP/CBZ layout cannot be selectively streamed." }
            val entries = readLeShort(tail, eocd + 10)
            val directorySize = readLeInt(tail, eocd + 12)
            val directoryOffset = readLeInt(tail, eocd + 16)
            require(entries != 0xFFFF && directorySize != 0xFFFFFFFFL && directoryOffset != 0xFFFFFFFFL) {
                "ZIP64 archives are not supported by low-storage streaming."
            }
            require(entries in 1..MAX_ZIP_ENTRIES) { "This ZIP/CBZ has too many entries for low-storage streaming." }
            require(directoryOffset >= 0L && directoryOffset + directorySize <= book.size) {
                "This ZIP/CBZ directory is malformed."
            }
            return EndOfCentralDirectory(entries, directoryOffset, directorySize)
        }
    }

    private fun parseArchiveIndex(book: TorrentBook, archive: File, eocd: EndOfCentralDirectory): ArchiveIndex {
        val entries = LinkedHashMap<String, ZipEntryData>()
        RandomAccessFile(archive, "r").use { raf ->
            raf.seek(eocd.directoryOffset)
            repeat(eocd.entryCount) {
                require(raf.readLeInt() == 0x02014b50L) { "This ZIP/CBZ directory is malformed." }
                raf.skipBytes(4)
                val flags = raf.readLeShort()
                val compression = raf.readLeShort()
                raf.skipBytes(4)
                raf.skipBytes(4)
                val compressedSize = raf.readLeInt()
                val uncompressedSize = raf.readLeInt()
                val nameLength = raf.readLeShort()
                val extraLength = raf.readLeShort()
                val commentLength = raf.readLeShort()
                raf.skipBytes(8)
                val localOffset = raf.readLeInt()
                val nameBytes = ByteArray(nameLength)
                raf.readFully(nameBytes)
                val name = String(nameBytes, if ((flags and 0x800) != 0) Charsets.UTF_8 else Charsets.ISO_8859_1)
                raf.skipBytes(extraLength + commentLength)
                if (!isImage(name)) return@repeat
                require(compressedSize != 0xFFFFFFFFL && uncompressedSize != 0xFFFFFFFFL && localOffset != 0xFFFFFFFFL) {
                    "ZIP64 image entries are not supported by low-storage streaming."
                }
                require(localOffset >= 0L && localOffset < book.size) { "This ZIP/CBZ entry is malformed." }
                entries[name] = ZipEntryData(name, flags, compression, compressedSize, uncompressedSize, localOffset)
            }
        }
        val pageNames = entries.keys.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })
        require(pageNames.isNotEmpty()) { "The selected archive contains no readable image pages." }
        return ArchiveIndex(pageNames, pageNames.first(), pageNames.associateWith { entries.getValue(it) })
    }

    private suspend fun readSelectedEntry(
        active: ActiveStream,
        book: TorrentBook,
        entry: ZipEntryData,
    ): ByteArray {
        require((entry.flags and 0x1) == 0) { "Encrypted ZIP/CBZ pages are not supported." }
        require(entry.compressedSize in 1..MAX_COMPRESSED_PAGE_BYTES) {
            "This page is too large for low-storage Torrent streaming."
        }
        require(entry.uncompressedSize in 1..MAX_UNCOMPRESSED_PAGE_BYTES) {
            "This page is too large to safely display from the Torrent stream."
        }
        requestRange(active, book, entry.localHeaderOffset, LOCAL_HEADER_SCAN_BYTES.coerceAtMost(book.size - entry.localHeaderOffset), "page header")
        val dataOffset = readLocalDataOffset(active.archive, entry, book)
        requestRange(active, book, dataOffset, entry.compressedSize, "page image")
        val compressedBytes = readArchiveRange(active.archive, dataOffset, entry.compressedSize)
        return when (entry.compressionMethod) {
            0 -> compressedBytes
            8 -> InflaterInputStream(compressedBytes.inputStream(), Inflater(true)).use {
                readBounded(it, MAX_UNCOMPRESSED_PAGE_BYTES)
            }
            else -> error("This ZIP/CBZ uses an unsupported image compression method.")
        }
    }

    private fun readLocalDataOffset(archive: File, entry: ZipEntryData, book: TorrentBook): Long {
        RandomAccessFile(archive, "r").use { raf ->
            raf.seek(entry.localHeaderOffset)
            require(raf.readLeInt() == 0x04034b50L) { "Torrent page header is not available yet." }
            raf.seek(entry.localHeaderOffset + 6)
            val flags = raf.readLeShort()
            val compression = raf.readLeShort()
            require((flags and 0x1) == 0 && compression == entry.compressionMethod) {
                "This ZIP/CBZ page header is unsupported."
            }
            raf.seek(entry.localHeaderOffset + 26)
            val nameLength = raf.readLeShort()
            val extraLength = raf.readLeShort()
            val dataOffset = entry.localHeaderOffset + 30L + nameLength + extraLength
            require(dataOffset + entry.compressedSize <= book.size) { "This ZIP/CBZ page range is malformed." }
            return dataOffset
        }
    }

    private suspend fun requestRange(
        active: ActiveStream,
        book: TorrentBook,
        offset: Long,
        length: Long,
        purpose: String,
    ) {
        require(length > 0L && offset >= 0L && offset + length <= book.size) { "Requested Torrent range is invalid." }
        val firstPiece = active.catalog.info.mapFile(book.fileIndex, offset, 1).piece()
        val lastPiece = active.catalog.info.mapFile(book.fileIndex, offset + length - 1L, 1).piece()
        val requested = (firstPiece..lastPiece).toList()
        val newPieces = requested.filterNot(active.requestedPieces::contains)
        val pieceLength = active.catalog.info.pieceLength().toLong().coerceAtLeast(1L)
        val prospectiveBytes = (active.requestedPieces.size.toLong() + newPieces.size.toLong()) * pieceLength
        require(prospectiveBytes <= TEMPORARY_PIECE_BUDGET_BYTES) {
            "This $purpose needs more than the 64 MiB temporary streaming limit. The archive will not be downloaded in full."
        }
        newPieces.forEach { piece ->
            active.handle.piecePriority(piece, Priority.TOP_PRIORITY)
            active.requestedPieces += piece
        }
        // Ask the native picker to fill this narrow selected range first. The piece budget above
        // remains the hard cap; no whole file is promoted or awaited.
        active.handle.setSequentialRange(firstPiece, lastPiece)
        active.handle.resume()
        while (requested.any { !active.handle.havePiece(it) }) {
            TorrentImportControl.awaitResume(context)
            check(!TorrentImportControl.isCancelled(context)) { "Torrent streaming was canceled." }
            if (System.nanoTime() >= active.deadlineNanos) {
                error("The requested $purpose was not available within 45 seconds. Check peers and retry; the archive was not downloaded in full.")
            }
            delay(50)
        }
    }

    private fun readArchiveRange(archive: File, offset: Long, length: Long): ByteArray {
        require(length in 1..MAX_COMPRESSED_PAGE_BYTES) { "Requested page range exceeds the low-storage limit." }
        return RandomAccessFile(archive, "r").use { raf ->
            raf.seek(offset)
            ByteArray(length.toInt()).also(raf::readFully)
        }
    }

    private fun readBounded(input: java.io.InputStream, limit: Long): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            require(output.size().toLong() + read <= limit) { "Decompressed Torrent page exceeds the safety limit." }
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }

    private fun cachedArchiveIndex(bookKey: String): ArchiveIndex? = synchronized(archiveIndexLock) {
        archiveIndexes[bookKey]
    }

    private fun cacheArchiveIndex(bookKey: String, index: ArchiveIndex) = synchronized(archiveIndexLock) {
        archiveIndexes[bookKey] = index
        while (archiveIndexes.size > INDEX_CACHE_ENTRIES) {
            archiveIndexes.entries.iterator().run {
                if (hasNext()) {
                    next()
                    remove()
                }
            }
        }
    }

    private suspend fun waitForHandle(catalog: TorrentCatalog): TorrentHandle = withContext(kotlinx.coroutines.Dispatchers.IO) {
        repeat(40) {
            findHandle(catalog)?.let { return@withContext it }
            delay(100)
        }
        error("Torrent session did not start.")
    }

    private fun findHandle(catalog: TorrentCatalog): TorrentHandle? = synchronized(sessionLock) {
        session?.find(catalog.info.infoHash())
    }

    private fun ensureSession(): SessionManager = ensureSessionBlocking()

    private fun ensureSessionBlocking(): SessionManager = synchronized(sessionLock) {
        session?.let { return@synchronized it }
        SessionManager(false).also {
            it.start()
            session = it
        }
    }

    private suspend fun releaseActiveStream(bookKey: String? = null) {
        val active = synchronized(activeStreamLock) {
            val current = activeStream ?: return
            if (bookKey != null && current.bookKey != bookKey) return
            activeStream = null
            current
        }
        runCatching { active.handle.pause() }
        // session_handle::delete_files is bit 0 in libtorrent's remove flags. The Java binding
        // exposes the same bitset through remove_flags_t. This asks the native engine to close
        // and delete its own pieces before the defensive directory cleanup below.
        runCatching { session?.remove(active.handle, remove_flags_t.from_int(1)) }
        startedCatalogs.remove(active.catalog.hash)
        // This is the only directory that libtorrent is allowed to write to. It contains no
        // retained metadata and is deleted after every cover, page-list or image response.
        repeat(3) {
            if (!active.catalog.saveDirectory.exists()) return
            active.catalog.saveDirectory.deleteRecursively()
            if (!active.catalog.saveDirectory.exists()) return
            delay(50)
        }
    }

    private fun findSignatureFromEnd(bytes: ByteArray, signature: Long): Int {
        for (index in bytes.size - 4 downTo 0) {
            if (readLeInt(bytes, index) == signature) return index
        }
        return -1
    }

    private fun readLeShort(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun readLeInt(bytes: ByteArray, offset: Int): Long =
        (readLeShort(bytes, offset).toLong() and 0xFFFF) or ((readLeShort(bytes, offset + 2).toLong() and 0xFFFF) shl 16)

    private fun RandomAccessFile.readLeShort(): Int = readUnsignedByte() or (readUnsignedByte() shl 8)

    private fun RandomAccessFile.readLeInt(): Long =
        readLeShort().toLong() or (readLeShort().toLong() shl 16)

    private fun imageType(name: String): String = when {
        name.endsWith(".png", true) -> "image/png"
        name.endsWith(".webp", true) -> "image/webp"
        name.endsWith(".gif", true) -> "image/gif"
        else -> "image/jpeg"
    }

    private fun isImage(name: String): Boolean = name.lowercase(Locale.ROOT).let {
        it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") ||
            it.endsWith(".webp") || it.endsWith(".gif")
    }
}
