package exh.ui.torrent

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.GetApp
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import eu.kanade.presentation.util.Screen
import eu.kanade.domain.manga.interactor.UpdateManga
import eu.kanade.tachiyomi.source.online.TorrentSource
import eu.kanade.tachiyomi.torrent.TorrentStreamManager
import kotlinx.coroutines.launch
import tachiyomi.domain.chapter.model.Chapter
import tachiyomi.domain.chapter.repository.ChapterRepository
import tachiyomi.domain.manga.interactor.NetworkToLocalManga
import tachiyomi.domain.manga.model.Manga
import tachiyomi.presentation.core.components.material.Scaffold
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

class TorrentImportScreen : Screen() {
    @Composable
    override fun Content() {
        val context = LocalContext.current
        val manager = remember { Injekt.get<TorrentStreamManager>() }
        val networkToLocalManga = remember { Injekt.get<NetworkToLocalManga>() }
        val chapterRepository = remember { Injekt.get<ChapterRepository>() }
        val updateManga = remember { Injekt.get<UpdateManga>() }
        val scope = rememberCoroutineScope()
        var link by remember { mutableStateOf("") }
        var status by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var paused by remember { mutableStateOf(false) }
        val notificationPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission(),
        ) { }

        fun requestNotificationsIfNeeded() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        fun importTorrent() {
            if (busy || link.isBlank()) return
            busy = true
            status = "Resolving torrent metadata…"
            requestNotificationsIfNeeded()
            scope.launch {
                runCatching {
                    val result = manager.importLink(link)
                    status = "Found ${result.books.size} CBZ/ZIP books in ${result.torrentName}. Adding metadata…"
                    val mangas = result.books.map { book ->
                        Manga.create().copy(
                            source = TorrentSource.ID,
                            url = book.key,
                            ogTitle = book.title,
                            ogArtist = book.artist,
                            ogAuthor = book.artist,
                            ogDescription = "Torrent-backed online stream • ${book.size / (1024 * 1024)} MiB",
                            ogGenre = listOf("Torrent"),
                            favorite = true,
                        )
                    }
                    val inserted = networkToLocalManga(mangas, updateInfo = false)
                    val newChapters = inserted.zip(result.books).mapNotNull { (manga, book) ->
                        if (chapterRepository.getChapterByUrlAndMangaId(book.key, manga.id) != null) return@mapNotNull null
                        Chapter.create().copy(
                            mangaId = manga.id,
                            url = book.key,
                            name = "Stream",
                            chapterNumber = 1.0,
                            sourceOrder = 0,
                            dateUpload = System.currentTimeMillis(),
                        )
                    }
                    if (newChapters.isNotEmpty()) chapterRepository.addAll(newChapters)
                    inserted.forEach { manga -> updateManga.awaitUpdateFavorite(manga.id, true) }
                    status = "${inserted.size} books available. Open one from the library to stream its pages on demand."
                }.onFailure { error ->
                    status = error.message ?: "Torrent import failed."
                }
                busy = false
            }
        }

        Scaffold { contentPadding ->
            Column(
                modifier = Modifier.padding(contentPadding).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.GetApp, contentDescription = null)
                    Text("Torrent", style = MaterialTheme.typography.titleLarge)
                }
                Text(
                    "Paste a Sukebei/Nyaa detail page, magnet, or direct .torrent URL. Komikku reads the torrent file list first, adds supported CBZ/ZIP items to the library, and fetches only the selected archive while you read. Filename and embedded metadata are used without inventing external details.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Sukebei/Nyaa, magnet, or .torrent link") },
                    placeholder = { Text("https://sukebei.nyaa.si/view/4051004") },
                    singleLine = true,
                )
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && link.isNotBlank(),
                    onClick = ::importTorrent,
                ) {
                    Text(if (busy) "Resolving and adding…" else "Add all books to library")
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        enabled = manager.allBooks().isNotEmpty() && !paused,
                        onClick = { paused = true; scope.launch { manager.pauseAll() } },
                    ) {
                        Icon(Icons.Outlined.Pause, contentDescription = null)
                        Text(" Pause")
                    }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        enabled = manager.allBooks().isNotEmpty() && paused,
                        onClick = { paused = false; scope.launch { manager.resumeAll() } },
                    ) {
                        Icon(Icons.Outlined.PlayArrow, contentDescription = null)
                        Text(" Resume")
                    }
                }
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    onClick = { scope.launch { manager.clearTemporaryCache(); status = "Temporary torrent cache cleared." } },
                ) {
                    Icon(Icons.Outlined.DeleteSweep, contentDescription = null)
                    Text(" Clear temporary stream cache")
                }
                if (status.isNotBlank()) {
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    "Streaming requires network data and a bounded temporary cache. It does not permanently download the complete torrent, but the currently read CBZ/ZIP may be cached temporarily. Metadata that cannot be derived from the torrent filename is not silently fabricated.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
