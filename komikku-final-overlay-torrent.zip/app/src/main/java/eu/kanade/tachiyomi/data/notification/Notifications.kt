package eu.kanade.tachiyomi.data.notification

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationManagerCompat.IMPORTANCE_DEFAULT
import androidx.core.app.NotificationManagerCompat.IMPORTANCE_HIGH
import androidx.core.app.NotificationManagerCompat.IMPORTANCE_LOW
import eu.kanade.tachiyomi.R
import eu.kanade.tachiyomi.data.connections.discord.RICH_PRESENCE_TAG
import eu.kanade.tachiyomi.util.system.buildNotificationChannel
import eu.kanade.tachiyomi.util.system.buildNotificationChannelGroup
import tachiyomi.core.common.i18n.stringResource
import tachiyomi.i18n.MR

/**
 * Class to manage the basic information of all the notifications used in the app.
 */
object Notifications {

    /**
     * Common notification channel and ids used anywhere.
     */
    const val CHANNEL_COMMON = "common_channel"
    /** Fine-grained channels used by Komikku runtime workflows. */
    const val CHANNEL_KOMIKKU_IMPORT = "komikku_import_channel"
    const val CHANNEL_KOMIKKU_RECOVERY = "komikku_recovery_channel"
    const val CHANNEL_KOMIKKU_DIAGNOSTICS = "komikku_diagnostics_channel"
    const val CHANNEL_KOMIKKU_SCHEDULED = "komikku_scheduled_channel"
    const val ID_KOMIKKU_IMPORT = -1801
    const val ID_KOMIKKU_RECOVERY = -1802
    const val ID_KOMIKKU_DIAGNOSTICS = -1803
    const val ID_KOMIKKU_SCHEDULED = -1804

    // Compatibility aliases for the existing batch-import and Nhentai reminder workflows.
    // They intentionally reuse registered Komikku channels rather than creating duplicate channels.
    const val CHANNEL_BATCH_IMPORT_PROGRESS = CHANNEL_KOMIKKU_IMPORT
    const val CHANNEL_BATCH_IMPORT_COMPLETE = CHANNEL_KOMIKKU_RECOVERY
    const val CHANNEL_NHENTAI_REMINDER = CHANNEL_KOMIKKU_SCHEDULED
    const val ID_BATCH_IMPORT_PROGRESS = ID_KOMIKKU_IMPORT
    const val ID_BATCH_IMPORT_COMPLETE = ID_KOMIKKU_RECOVERY
    const val ID_NHENTAI_DAILY_REMINDER = ID_KOMIKKU_SCHEDULED

    const val ID_DOWNLOAD_IMAGE = 2

    /**
     * Notification channel and ids used by the library updater.
     */
    private const val GROUP_LIBRARY = "group_library"
    private const val GROUP_KOMIKKU = "group_komikku_runtime"
    const val CHANNEL_LIBRARY_PROGRESS = "library_progress_channel"
    const val ID_LIBRARY_PROGRESS = -101
    const val ID_LIBRARY_SIZE_WARNING = -103
    const val CHANNEL_LIBRARY_ERROR = "library_errors_channel"
    const val ID_LIBRARY_ERROR = -102
    const val CHANNEL_LIBRARY_EHENTAI = "library_ehentai_channel"
    const val ID_EHENTAI_PROGRESS = -199
    const val ID_EHENTAI_ERROR = -198

    /**
     * Notification channel and ids used by the downloader.
     */
    private const val GROUP_DOWNLOADER = "group_downloader"
    const val CHANNEL_DOWNLOADER_PROGRESS = "downloader_progress_channel"
    const val ID_DOWNLOAD_CHAPTER_PROGRESS = -201
    // KMK -->
    const val ID_DOWNLOAD_CHAPTER_PAUSED = -203
    // KMK <--
    const val CHANNEL_DOWNLOADER_ERROR = "downloader_error_channel"
    const val ID_DOWNLOAD_CHAPTER_ERROR = -202

    /**
     * Notification channel and ids used by the library updater.
     */
    const val CHANNEL_NEW_CHAPTERS = "new_chapters_channel"
    const val ID_NEW_CHAPTERS = -301
    const val GROUP_NEW_CHAPTERS = "eu.kanade.tachiyomi.NEW_CHAPTERS"

    /**
     * Notification channel and ids used by the backup/restore/sync system.
     */
    private const val GROUP_BACKUP_RESTORE = "group_backup_restore"
    const val CHANNEL_BACKUP_RESTORE_PROGRESS = "backup_restore_progress_channel"
    const val ID_BACKUP_PROGRESS = -501
    const val ID_RESTORE_PROGRESS = -503
    const val CHANNEL_BACKUP_RESTORE_COMPLETE = "backup_restore_complete_channel_v2"
    const val ID_BACKUP_COMPLETE = -502
    const val ID_RESTORE_COMPLETE = -504
    const val CHANNEL_SYNC_LIBRARY = "syncing_library_channel"
    const val ID_SYNC_PROGRESS = -505
    const val ID_SYNC_COMPLETE = -506

    /**
     * Notification channel used for Incognito Mode
     */
    const val CHANNEL_INCOGNITO_MODE = "incognito_mode_channel"
    const val ID_INCOGNITO_MODE = -701

    // AM (DISCORD) -->
    /**
     * Notification channel used for Discord RPC
     */
    const val CHANNEL_DISCORD_RPC = "${RICH_PRESENCE_TAG}_channel"
    const val ID_DISCORD_RPC = -1701
    // <-- AM (DISCORD)

    /**
     * Notification channel and ids used for app and extension updates.
     */
    private const val GROUP_APK_UPDATES = "group_apk_updates"
    const val CHANNEL_APP_UPDATE = "app_apk_update_channel"
    const val ID_APP_UPDATER = 1
    const val ID_APP_UPDATE_PROMPT = 2
    const val ID_APP_UPDATE_ERROR = 3

    // KMK -->
    const val ID_APP_INSTALL = 4
    const val ID_APP_INSTALLED = 5
    // KMK <--

    const val CHANNEL_EXTENSIONS_UPDATE = "ext_apk_update_channel"
    const val ID_UPDATES_TO_EXTS = -401
    const val ID_EXTENSION_INSTALLER = -402

    private val deprecatedChannels = listOf(
        "downloader_channel",
        "downloader_complete_channel",
        "backup_restore_complete_channel",
        "library_channel",
        "library_progress_channel",
        "updates_ext_channel",
        "downloader_cache_renewal",
        "crash_logs_channel",
        "library_skipped_channel",
    )

    /**
     * Creates the notification channels introduced in Android Oreo.
     * This won't do anything on Android versions that don't support notification channels.
     *
     * @param context The application context.
     */
    fun createChannels(context: Context) {
        val notificationManager = NotificationManagerCompat.from(context)

        // Delete old notification channels
        deprecatedChannels.forEach(notificationManager::deleteNotificationChannel)

        notificationManager.createNotificationChannelGroupsCompat(
            listOf(
                buildNotificationChannelGroup(GROUP_BACKUP_RESTORE) {
                    setName(context.stringResource(MR.strings.label_backup))
                },
                buildNotificationChannelGroup(GROUP_DOWNLOADER) {
                    setName(context.stringResource(MR.strings.download_notifier_downloader_title))
                },
                buildNotificationChannelGroup(GROUP_LIBRARY) {
                    setName(context.stringResource(MR.strings.label_library))
                },
                buildNotificationChannelGroup(GROUP_APK_UPDATES) {
                    setName(context.stringResource(MR.strings.label_recent_updates))
                },
                buildNotificationChannelGroup(GROUP_KOMIKKU) {
                    setName("Komikku runtime")
                },
            ),
        )

        notificationManager.createNotificationChannelsCompat(
            listOf(
                buildNotificationChannel(CHANNEL_COMMON, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.channel_common))
                },
                buildNotificationChannel(CHANNEL_KOMIKKU_IMPORT, IMPORTANCE_LOW) {
                    setName("Import progress")
                    setGroup(GROUP_KOMIKKU)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_KOMIKKU_RECOVERY, IMPORTANCE_DEFAULT) {
                    setName("Recovery and failures")
                    setGroup(GROUP_KOMIKKU)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_KOMIKKU_DIAGNOSTICS, IMPORTANCE_LOW) {
                    setName("Diagnostics")
                    setGroup(GROUP_KOMIKKU)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_KOMIKKU_SCHEDULED, IMPORTANCE_DEFAULT) {
                    setName("Scheduled jobs")
                    setGroup(GROUP_KOMIKKU)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_LIBRARY_PROGRESS, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.channel_progress))
                    setGroup(GROUP_LIBRARY)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_LIBRARY_ERROR, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.channel_errors))
                    setGroup(GROUP_LIBRARY)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_NEW_CHAPTERS, IMPORTANCE_DEFAULT) {
                    setName(context.stringResource(MR.strings.channel_new_chapters))
                },
                buildNotificationChannel(CHANNEL_DOWNLOADER_PROGRESS, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.channel_progress))
                    setGroup(GROUP_DOWNLOADER)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_DOWNLOADER_ERROR, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.channel_errors))
                    setGroup(GROUP_DOWNLOADER)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_BACKUP_RESTORE_PROGRESS, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.channel_progress))
                    setGroup(GROUP_BACKUP_RESTORE)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_BACKUP_RESTORE_COMPLETE, IMPORTANCE_HIGH) {
                    setName(context.stringResource(MR.strings.channel_complete))
                    setGroup(GROUP_BACKUP_RESTORE)
                    setShowBadge(false)
                    setSound(null, null)
                },
                buildNotificationChannel(CHANNEL_SYNC_LIBRARY, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.syncing_library))
                    setGroup(GROUP_BACKUP_RESTORE)
                    setShowBadge(false)
                },
                buildNotificationChannel(CHANNEL_INCOGNITO_MODE, IMPORTANCE_LOW) {
                    setName(context.stringResource(MR.strings.pref_incognito_mode))
                },
                buildNotificationChannel(CHANNEL_APP_UPDATE, IMPORTANCE_HIGH) {
                    setGroup(GROUP_APK_UPDATES)
                    setName(context.stringResource(MR.strings.channel_app_updates))
                },
                buildNotificationChannel(CHANNEL_EXTENSIONS_UPDATE, IMPORTANCE_DEFAULT) {
                    setGroup(GROUP_APK_UPDATES)
                    setName(context.stringResource(MR.strings.channel_ext_updates))
                },
                // AM (DISCORD) -->
                buildNotificationChannel(CHANNEL_DISCORD_RPC, IMPORTANCE_LOW) {
                    setName(context.getString(R.string.pref_discord_rpc))
                },
                // <-- AM (DISCORD)
                // SY -->
                buildNotificationChannel(CHANNEL_LIBRARY_EHENTAI, IMPORTANCE_LOW) {
                    setName("EHentai")
                    setGroup(GROUP_LIBRARY)
                    setShowBadge(false)
                },
                // SY <--
            ),
        )
    }
}
