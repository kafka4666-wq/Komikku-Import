package eu.kanade.tachiyomi.torrent

import android.content.Context
import eu.kanade.tachiyomi.network.NetworkHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.jsoup.Jsoup
import org.libtorrent4j.Priority
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentFlags
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipFile

/**
 * Torrent-backed streaming coordinator. It never marks the complete torrent as wanted:
 * all files start at priority IGNORE, and only the CBZ/ZIP currently being read is selected.
 * The selected archive is temporarily cached and is eligible for eviction after the cache
 * limit is reached. No full-torrent prefetch or startup session is performed.
 */
class TorrentStreamManager(
    private val context: Context,
) {
    private val lock = Mutex()
    private val catalogs = ConcurrentHashMap<String, TorrentCatalog>()
    private val archiveLru = LinkedHashMap<String, File>(32, 0.75f, true)
    private val archiveLruLock = Any()
    private val cacheLimitBytes = 512L * 1024L * 1024L
    private val torrentRoot = File(context.cacheDir, "torrent_stream").apply { mkdirs() }
    private var session: SessionManager? = null

    data class TorrentBook(
        val key: String,
        val torrentHash: String,
        val fileIndex: Int,
        val path: String,
        val title: String,
        val artist: String?,
        val size: Long,
    )

    data class TorrentImportResult(
        val torrentHash: String,
        val torrentName: String,
        val books: List<TorrentBook>,
        val totalBytes: Long,
    )

    private data class TorrentCatalog(
        val hash: String,
        val info: TorrentInfo,
        val books: List<TorrentBook>,
        val saveDirectory: File,
    )

    suspend fun importLink(input: String): TorrentImportResult = withContext(Dispatchers.IO) {
        val normalized = input.trim()
        require(normalized.isNotEmpty()) { "Enter a magnet, .torrent URL, or Sukebei/Nyaa detail URL." }
        lock.withLock {
            val torrentBytes = resolveMetainfo(normalized)
            val info = TorrentInfo(torrentBytes)
            require(info.isValid) { "The supplied link did not contain valid torrent metadata." }
            val hash = info.infoHash().toHex().lowercase(Locale.ROOT)
            val name = info.files().name().ifBlank { "Torrent $hash" }
            val saveDirectory = File(torrentRoot, hash).apply { mkdirs() }
            val storage = info.files()
            val books = buildList {
                for (index in 0 until storage.numFiles()) {
                    val path = storage.filePath(index)
                    val lower = path.lowercase(Locale.ROOT)
                    if (!lower.endsWith(".cbz") && !lower.endsWith(".zip")) continue
                    if (storage.fileSize(index) <= 0L) continue
                    val fileName = storage.fileName(index)
                    val title = fileName.substringBeforeLast('.', fileName).trim().ifBlank { fileName }
                    val artist = Regex("^\\[([^]]+)]").find(title)?.groupValues?.getOrNull(1)?.trim()
                    add(
                        TorrentBook(
                            key = "$hash/$index",
                            torrentHash = hash,
                            fileIndex = index,
                            path = path,
                            title = title,
                            artist = artist,
                            size = storage.fileSize(index),
                        ),
                    )
                }
            }
            require(books.isNotEmpty()) { "No supported CBZ or ZIP doujin archives were found in this torrent." }
            val catalog = TorrentCatalog(hash, info, books, saveDirectory)
            catalogs[hash] = catalog
            startSelectiveSession(catalog)
            TorrentImportResult(hash, name, books, info.totalSize())
        }
    }

    fun allBooks(): List<TorrentBook> = catalogs.values.flatMap { it.books }

    fun findBook(key: String): TorrentBook? {
        val hash = key.substringBefore('/')
        return catalogs[hash]?.books?.firstOrNull { it.key == key }
    }

    suspend fun pageNames(bookKey: String): List<String> = withContext(Dispatchers.IO) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        val archive = ensureArchive(book)
        ZipFile(archive).use { zip ->
            zip.entries().asSequence()
                .filter { !it.isDirectory && isImage(it.name) }
                .map { it.name }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it })
                .toList()
        }
    }

    suspend fun readPage(bookKey: String, entryName: String): Pair<ByteArray, String> = withContext(Dispatchers.IO) {
        val book = requireNotNull(findBook(bookKey)) { "Torrent item is no longer available." }
        val archive = ensureArchive(book)
        ZipFile(archive).use { zip ->
            val entry = zip.getEntry(entryName) ?: error("Torrent page is not present in the archive.")
            val type = when {
                entryName.endsWith(".png", true) -> "image/png"
                entryName.endsWith(".webp", true) -> "image/webp"
                entryName.endsWith(".gif", true) -> "image/gif"
                else -> "image/jpeg"
            }
            zip.getInputStream(entry).use { it.readBytes() } to type
        }
    }

    suspend fun pauseAll() = withContext(Dispatchers.IO) {
        catalogs.values.forEach { catalog -> findHandle(catalog)?.pause() }
    }

    suspend fun resumeAll() = withContext(Dispatchers.IO) {
        catalogs.values.forEach { catalog -> findHandle(catalog)?.resume() }
    }

    suspend fun clearTemporaryCache() = withContext(Dispatchers.IO) {
        synchronized(archiveLruLock) { archiveLru.clear() }
        torrentRoot.listFiles().orEmpty().forEach { it.deleteRecursively() }
    }

    private suspend fun resolveMetainfo(input: String): ByteArray {
        if (input.startsWith("magnet:", true)) {
            ensureSession()
            return requireNotNull(session!!.fetchMagnet(input, 45, torrentRoot)) {
                "Magnet metadata could not be resolved from the current peers/trackers."
            }
        }
        val response = Injekt.get<NetworkHelper>().client.newCall(Request.Builder().url(input).build()).execute()
        response.use {
            require(it.isSuccessful) { "Torrent link returned HTTP ${it.code}." }
            val bytes = it.body?.bytes() ?: error("Torrent link returned an empty response.")
            val contentType = it.header("Content-Type").orEmpty().lowercase(Locale.ROOT)
            val looksLikeHtml = contentType.contains("html") || input.contains("/view/", true)
            if (!looksLikeHtml && !input.endsWith(".html", true)) return bytes
            val document = Jsoup.parse(bytes.toString(Charsets.UTF_8), input)
            val magnet = document.selectFirst("a[href^=magnet:]")?.attr("href")
                ?.let { URLDecoder.decode(it, Charsets.UTF_8.name()) }
            if (magnet.isNullOrBlank()) {
                val id = Regex("/view/(\\d+)").find(input)?.groupValues?.getOrNull(1)
                val fallback = id?.let { "${input.substringBefore("/view/")}/download/$it.torrent" }
                if (fallback != null) return resolveMetainfo(fallback)
                error("No magnet or .torrent link was found on the supplied Nyaa/Sukebei page.")
            }
            ensureSession()
            return requireNotNull(session!!.fetchMagnet(magnet, 45, torrentRoot)) {
                "Magnet metadata could not be resolved from the supplied page."
            }
        }
    }

    private fun startSelectiveSession(catalog: TorrentCatalog) {
        val priorities = Priority.array(Priority.IGNORE, catalog.info.files().numFiles())
        ensureSessionBlocking().download(
            catalog.info,
            catalog.saveDirectory,
            null,
            priorities,
            null,
            TorrentFlags.AUTO_MANAGED.or_(TorrentFlags.UPDATE_SUBSCRIBE),
        )
    }

    private suspend fun ensureArchive(book: TorrentBook): File {
        val catalog = requireNotNull(catalogs[book.torrentHash]) { "Torrent session is no longer active." }
        val target = File(catalog.info.files().filePath(book.fileIndex, catalog.saveDirectory.absolutePath))
        synchronized(archiveLruLock) {
            archiveLru[book.key] = target
        }
        if (!target.exists() || target.length() < book.size) {
            val handle = waitForHandle(catalog)
            handle.filePriority(book.fileIndex, Priority.TOP_PRIORITY)
            handle.resume()
            var downloaded = 0L
            for (attempt in 0 until 720) {
                delay(500)
                val progress = runCatching { handle.fileProgress(TorrentHandle.PIECE_GRANULARITY) }.getOrNull()
                downloaded = progress?.getOrNull(book.fileIndex) ?: downloaded
                if (downloaded >= book.size && target.exists() && target.length() >= book.size) break
            }
            require(target.exists() && target.length() >= book.size) {
                "The selected torrent archive is not available yet. Peers may be offline or the torrent may be incomplete."
            }
            handle.pause()
        }
        pruneCache()
        return target
    }

    private suspend fun waitForHandle(catalog: TorrentCatalog): TorrentHandle = withContext(Dispatchers.IO) {
        repeat(90) {
            findHandle(catalog)?.let { return@withContext it }
            delay(500)
        }
        error("Torrent session did not start.")
    }

    private fun findHandle(catalog: TorrentCatalog): TorrentHandle? =
        ensureSessionBlocking().find(catalog.info.infoHash())

    private fun ensureSession(): SessionManager {
        return ensureSessionBlocking()
    }

    private fun ensureSessionBlocking(): SessionManager {
        session?.let { return it }
        return SessionManager(false).also {
            it.start()
            session = it
        }
    }

    private fun pruneCache() {
        synchronized(archiveLruLock) {
            var total = archiveLru.values.distinct().filter(File::exists).sumOf(File::length)
            val iterator = archiveLru.entries.iterator()
            while (total > cacheLimitBytes && iterator.hasNext()) {
                val entry = iterator.next()
                val file = entry.value
                if (file.exists()) total -= file.length()
                file.delete()
                iterator.remove()
            }
        }
    }

    private fun isImage(name: String): Boolean = name.lowercase(Locale.ROOT).let {
        it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") ||
            it.endsWith(".webp") || it.endsWith(".gif")
    }
}
