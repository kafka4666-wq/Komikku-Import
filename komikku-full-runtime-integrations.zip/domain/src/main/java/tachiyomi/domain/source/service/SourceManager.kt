package tachiyomi.domain.source.service

import eu.kanade.tachiyomi.source.Source
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import tachiyomi.domain.source.model.StubSource

interface SourceManager {

    val isInitialized: StateFlow<Boolean>

    val sources: Flow<List<Source>>

    fun get(sourceKey: Long): Source?

    fun getOrStub(sourceKey: Long): Source

    fun getAll(): List<Source>

    fun getOnlineSources(): List<HttpSource>

    // SY -->
    fun getVisibleOnlineSources(): List<HttpSource>

    fun getVisibleSources(): List<Source>
    // SY <--

    // KMK -->
    suspend fun getMergedSources(mangaId: Long): List<Source>
    // KMK <--

    fun getStubSources(): List<StubSource>

    /**
     * Versioned Komikku source contract. Existing extensions remain v1-compatible
     * through these defaults; newer adapters can override capabilities explicitly.
     */
    fun adapterApiVersion(sourceKey: Long): Int = 1

    fun supportsCapability(sourceKey: Long, capability: SourceCapability): Boolean = when (capability) {
        SourceCapability.SEARCH,
        SourceCapability.PAGINATION,
        SourceCapability.DETAILS,
        -> get(sourceKey) != null
        SourceCapability.OFFLINE_CACHE,
        SourceCapability.MIGRATION,
        -> false
    }

    fun compatibleSource(sourceKey: Long): SourceCompatibility = when {
        get(sourceKey) == null -> SourceCompatibility.UNAVAILABLE
        adapterApiVersion(sourceKey) >= 2 -> SourceCompatibility.V2
        else -> SourceCompatibility.V1
    }
}

enum class SourceCapability {
    SEARCH,
    PAGINATION,
    DETAILS,
    OFFLINE_CACHE,
    MIGRATION,
}

enum class SourceCompatibility {
    V1,
    V2,
    UNAVAILABLE,
}
