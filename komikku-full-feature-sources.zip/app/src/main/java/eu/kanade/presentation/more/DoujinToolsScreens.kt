package eu.kanade.presentation.more

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cafe.adriel.voyager.navigator.LocalNavigator
import eu.kanade.domain.ui.DoujinFeatureEngine
import eu.kanade.tachiyomi.ui.manga.MangaScreen
import eu.kanade.presentation.util.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tachiyomi.domain.manga.model.Manga
import tachiyomi.domain.manga.repository.MangaRepository
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File

class DoujinToolsScreen : Screen() {
    @Composable
    override fun Content() {
        val navigator = LocalNavigator.current ?: return
        val context = LocalContext.current
        val repository = remember { Injekt.get<MangaRepository>() }
        var loading by remember { mutableStateOf(false) }
        var report by remember { mutableStateOf("Choose a bounded tool. No operation changes library data automatically.") }
        var duplicateGroups by remember { mutableStateOf<List<List<DoujinFeatureEngine.DuplicateCandidate>>>(emptyList()) }
        var metadataIssues by remember { mutableStateOf<List<DoujinFeatureEngine.MetadataIssue>>(emptyList()) }
        var random by remember { mutableStateOf<Manga?>(null) }
        var offset by remember { mutableStateOf(0) }

        suspend fun runPageScan(action: suspend (List<Manga>) -> Unit) {
            if (loading) return
            loading = true
            try {
                val page = withContext(Dispatchers.IO) {
                    DoujinFeatureEngine.favoriteWindow(repository, 100, offset)
                }
                action(page)
                report = "Inspected ${page.size} library entries (window offset $offset). Select Next window to continue."
            } catch (error: Exception) {
                report = "Scan stopped safely: ${error.message ?: "database error"}"
            } finally {
                loading = false
            }
        }

        Scaffold(
            topBar = { TopAppBar(title = { Text("Doujin Tools") }, navigationIcon = { TextButton(onClick = navigator::pop) { Text("Back") } }) },
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Text(
                        "Bounded, review-first tools for large libraries. Scans process 100 entries at a time and never delete or merge automatically.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                item {
                    ToolCard("Duplicate Scanner", "Compare real library entries using title, author, artist/circle, tags, and source signals.") {
                        Button(onClick = {
                            if (!loading) {
                                loading = true
                                CoroutineScope(Dispatchers.Main).launch {
                                    try {
                                        val entries = withContext(Dispatchers.IO) { repository.getDuplicateLibraryEntries(400) }
                                        duplicateGroups = entries.groupBy { DoujinFeatureEngine.titleKey(it) }
                                            .values.filter { it.size > 1 }.map { group ->
                                                group.mapIndexed { index, manga ->
                                                    val peer = group.firstOrNull { it.id != manga.id }
                                                    val scored = peer?.let { DoujinFeatureEngine.duplicateCandidate(manga, it) }
                                                    DoujinFeatureEngine.DuplicateCandidate(
                                                        manga,
                                                        scored?.confidence ?: 100,
                                                        scored?.signals ?: listOf("same normalized title"),
                                                    )
                                                }
                                            }
                                        report = "Found ${duplicateGroups.size} review groups from the database-bounded duplicate query."
                                    } catch (error: Exception) {
                                        report = "Duplicate scan stopped safely: ${error.message ?: "database error"}"
                                    } finally { loading = false }
                                }
                            }
                        }, enabled = !loading) { Text(if (loading) "Scanning…" else "Scan duplicate groups") }
                    }
                }
                items(duplicateGroups) { group ->
                    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            group.forEach { candidate ->
                                TextButton(onClick = { navigator.push(MangaScreen(candidate.manga.id)) }) {
                                    Text("${candidate.manga.title} · ${candidate.confidence}% · ${candidate.signals.joinToString()}")
                                }
                            }
                            Text("Review only: keep, ignore, or migrate manually; metadata and reading history are preserved.", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item {
                    ToolCard("Metadata Scanner", "Find missing covers, descriptions, creators, or tags in a bounded library window.") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { CoroutineScope(Dispatchers.Main).launch { runPageScan { page -> metadataIssues = page.map(DoujinFeatureEngine::metadataIssues).filter { it.missing.isNotEmpty() } } } }, enabled = !loading) { Text("Scan") }
                            Button(onClick = { offset += 100; report = "Next metadata window is ready at offset $offset." }, enabled = !loading) { Text("Next window") }
                        }
                    }
                }
                items(metadataIssues) { issue ->
                    TextButton(onClick = { navigator.push(MangaScreen(issue.manga.id)) }, modifier = Modifier.padding(horizontal = 16.dp)) {
                        Text("${issue.manga.title}: missing ${issue.missing.joinToString()}")
                    }
                }
                item {
                    ToolCard("Gallery Integrity Scanner", "Check a bounded portion of local app storage for unreadable or zero-byte gallery files.") {
                        Button(onClick = { report = scanGalleryIntegrity(context) }) { Text("Check local files") }
                    }
                }
                item {
                    ToolCard("Smart Random Discovery", "Select a candidate from the next library window, with optional fuzzy title ranking.") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { CoroutineScope(Dispatchers.Main).launch { runPageScan { page -> random = DoujinFeatureEngine.selectRandom(page) } } }, enabled = !loading) { Text("Pick random") }
                            random?.let { TextButton(onClick = { navigator.push(MangaScreen(it.id)) }) { Text(it.title) } }
                        }
                    }
                }
                item {
                    ToolCard("Creators, Tags, Bookmarks, and Heatmap", "Open discovery for fuzzy search, advanced tag combinations, creator grouping, personal tags, source-agnostic review, and local reading statistics.") {
                        Button(onClick = { navigator.push(DoujinDiscoveryScreen()) }) { Text("Open Discovery") }
                        val heat = DoujinFeatureEngine.heatmap(context)
                        Text("Saved page bookmarks: local and separate from source metadata. Reading heatmap: ${heat.values.sum()} recorded pages.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    Text(report, Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

class DoujinDiscoveryScreen : Screen() {
    @Composable
    override fun Content() {
        val navigator = LocalNavigator.current ?: return
        val repository = remember { Injekt.get<MangaRepository>() }
        val context = LocalContext.current
        var query by remember { mutableStateOf("") }
        var include by remember { mutableStateOf("") }
        var exclude by remember { mutableStateOf("") }
        var exactTags by remember { mutableStateOf(false) }
        var items by remember { mutableStateOf<List<Manga>>(emptyList()) }
        var offset by remember { mutableStateOf(0) }
        var loading by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Discovery is local and paged.") }

        suspend fun loadNext() {
            if (loading) return
            loading = true
            try {
                val page = withContext(Dispatchers.IO) { DoujinFeatureEngine.favoriteWindow(repository, 100, offset) }
                val seen = DoujinFeatureEngine.seenIds(context)
                val filtered = page.asSequence()
                    .filter { DoujinFeatureEngine.tagExpressionMatches(it, include, exclude, exactTags) }
                    .filter { query.isBlank() || DoujinFeatureEngine.fuzzyScore(query, it) >= 0.35f }
                    .filter { it.id !in seen }
                    .sortedByDescending { DoujinFeatureEngine.fuzzyScore(query, it) }
                    .toList()
                items = (items + filtered).distinctBy { it.id }.take(300)
                offset += page.size
                status = "Loaded ${filtered.size} new results; window offset $offset."
            } catch (error: Exception) {
                status = "Discovery stopped safely: ${error.message ?: "database error"}"
            } finally { loading = false }
        }

        Scaffold(
            topBar = { TopAppBar(title = { Text("Doujin Discovery") }, navigationIcon = { TextButton(onClick = navigator::pop) { Text("Back") } }) },
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Paged local discovery", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Fuzzy title / creator") })
                        OutlinedTextField(include, { include = it }, Modifier.fillMaxWidth(), label = { Text("Include tags, comma separated") })
                        OutlinedTextField(exclude, { exclude = it }, Modifier.fillMaxWidth(), label = { Text("Exclude tags, comma separated") })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { exactTags = !exactTags }) { Text(if (exactTags) "Exact tags: on" else "Partial tags: on") }
                            Button(onClick = { items = emptyList(); offset = 0; CoroutineScope(Dispatchers.Main).launch { loadNext() } }, enabled = !loading) { Text("Refresh") }
                            Button(onClick = { CoroutineScope(Dispatchers.Main).launch { loadNext() } }, enabled = !loading) { Text("Next page") }
                        }
                        Text(status, style = MaterialTheme.typography.bodySmall)
                    }
                }
                items(items, key = { it.id }) { manga ->
                    Column(Modifier.fillMaxWidth().clickable { DoujinFeatureEngine.rememberSeen(context, listOf(manga.id)); navigator.push(MangaScreen(manga.id)) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(manga.title, style = MaterialTheme.typography.titleSmall)
                        Text("${manga.author ?: manga.artist ?: "Unknown creator"} · tags: ${manga.genre.orEmpty().take(5).joinToString()}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                item { Text("Discovery remembers seen IDs locally and keeps source metadata unchanged.", Modifier.padding(16.dp), style = MaterialTheme.typography.labelSmall) }
            }
        }
    }
}

@Composable
private fun ToolCard(title: String, subtitle: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
            content()
        }
    }
}

private fun scanGalleryIntegrity(context: Context): String {
    val roots = listOfNotNull(context.getExternalFilesDir(null), context.filesDir)
    var inspected = 0
    var zeroByte = 0
    var unreadable = 0
    roots.forEach { root ->
        root.walkTopDown().onEnter { inspected < 200 }.forEach { file ->
            if (!file.isFile || inspected >= 200) return@forEach
            inspected++
            if (file.length() == 0L) zeroByte++
            if (!file.canRead()) unreadable++
        }
    }
    return "Inspected $inspected local files. Zero-byte: $zeroByte; unreadable: $unreadable. No files were changed."
}
