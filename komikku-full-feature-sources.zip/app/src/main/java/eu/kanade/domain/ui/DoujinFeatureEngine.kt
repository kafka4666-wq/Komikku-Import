package eu.kanade.domain.ui

import android.content.Context
import android.view.Window
import android.view.WindowManager
import tachiyomi.domain.manga.model.Manga
import tachiyomi.domain.manga.repository.MangaRepository
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random
import java.util.Locale

/**
 * Local-only runtime helpers for the Doujin customisations. The engine deliberately
 * works on bounded pages and stores only small user-owned indexes in app preferences.
 * It never edits, deletes, merges, or replaces a Manga record.
 */
object DoujinFeatureEngine {
    private const val STORE = "doujin_runtime_v1"
    private const val SEEN_KEY = "discovery_seen"
    private const val PERSONAL_TAG_KEY = "personal_tags"
    private const val BOOKMARK_KEY = "page_bookmarks"
    private const val HEATMAP_KEY = "reading_heatmap"
    private const val MAX_STORED_IDS = 20_000
    private const val MAX_STORED_TAGS = 100
    private const val MAX_BOOKMARKS = 2_000

    data class DuplicateCandidate(
        val manga: Manga,
        val confidence: Int,
        val signals: List<String>,
    )

    data class MetadataIssue(
        val manga: Manga,
        val missing: List<String>,
    )

    data class PageBookmark(
        val mangaId: Long,
        val chapterId: Long,
        val page: Int,
        val note: String = "",
    )

    fun normalize(value: String?): String = value.orEmpty()
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    fun titleKey(manga: Manga): String = normalize(manga.title)

    fun creatorKey(manga: Manga): String = normalize(manga.artist ?: manga.author)
        .ifBlank { normalize(manga.author ?: manga.artist) }
        .ifBlank { "unknown creator" }

    fun tags(manga: Manga): Set<String> = manga.genre.orEmpty()
        .map(::normalize)
        .filter(String::isNotBlank)
        .toSet()

    fun tagExpressionMatches(
        manga: Manga,
        include: String,
        exclude: String,
        exact: Boolean,
    ): Boolean {
        val available = tags(manga)
        val required = parseTags(include)
        val blocked = parseTags(exclude)
        val includesMatch = required.all { wanted ->
            if (exact) wanted in available else available.any { it == wanted || it.contains(wanted) }
        }
        val excludesMatch = blocked.none { unwanted ->
            if (exact) unwanted in available else available.any { it == unwanted || it.contains(unwanted) }
        }
        return includesMatch && excludesMatch
    }

    fun parseTags(value: String): Set<String> = value.split(',', '\n', ';')
        .asSequence()
        .map(::normalize)
        .filter(String::isNotBlank)
        .take(64)
        .toSet()

    fun fuzzyScore(query: String, manga: Manga): Float {
        val needle = normalize(query)
        if (needle.isBlank()) return 1f
        val haystack = listOf(manga.title, manga.author, manga.artist)
            .map(::normalize)
            .filter(String::isNotBlank)
        if (haystack.any { it == needle }) return 1f
        if (haystack.any { it.contains(needle) }) return 0.9f
        return haystack.maxOfOrNull { field ->
            val distance = levenshtein(needle, field.take(160))
            1f - min(1f, distance.toFloat() / max(needle.length, field.length).coerceAtLeast(1))
        } ?: 0f
    }

    fun similarityScore(left: Manga, right: Manga, tagWeights: Map<String, Float> = emptyMap()): Float {
        val title = fuzzyScore(left.title, right)
        val creator = when {
            creatorKey(left) == creatorKey(right) && creatorKey(left) != "unknown creator" -> 1f
            !left.author.isNullOrBlank() && left.author == right.author -> 0.85f
            !left.artist.isNullOrBlank() && left.artist == right.artist -> 0.85f
            else -> 0f
        }
        val overlap = tags(left).intersect(tags(right))
        val weightedOverlap = if (overlap.isEmpty()) 0f else {
            val numerator = overlap.sumOf { tagWeights[it] ?: 1f }
            val denominator = tags(left).union(tags(right)).sumOf { tagWeights[it] ?: 1f }
            (numerator / denominator.coerceAtLeast(0.01f)).coerceIn(0f, 1f)
        }
        return (title * 0.55f + creator * 0.25f + weightedOverlap * 0.20f).coerceIn(0f, 1f)
    }

    fun duplicateCandidate(left: Manga, right: Manga): DuplicateCandidate {
        val signals = buildList {
            if (titleKey(left).isNotBlank() && titleKey(left) == titleKey(right)) add("same title")
            if (!left.author.isNullOrBlank() && normalize(left.author) == normalize(right.author)) add("same author")
            if (!left.artist.isNullOrBlank() && normalize(left.artist) == normalize(right.artist)) add("same artist/circle")
            if (tags(left).intersect(tags(right)).isNotEmpty()) add("overlapping tags")
            if (left.source == right.source) add("same source")
        }
        val score = (similarityScore(left, right) * 100).toInt().coerceIn(0, 100)
        return DuplicateCandidate(right, score, signals)
    }

    fun metadataIssues(manga: Manga): MetadataIssue {
        val missing = buildList {
            if (manga.title.isBlank()) add("title")
            if (manga.thumbnailUrl.isNullOrBlank()) add("cover")
            if (manga.description.isNullOrBlank()) add("description")
            if (manga.author.isNullOrBlank() && manga.artist.isNullOrBlank()) add("creator")
            if (manga.genre.isNullOrEmpty()) add("tags")
        }
        return MetadataIssue(manga, missing)
    }

    suspend fun favoriteWindow(repository: MangaRepository, limit: Int, offset: Int): List<Manga> =
        repository.getFavoriteMangaPage(limit.coerceIn(1, 200).toLong(), offset.coerceAtLeast(0).toLong())

    fun selectRandom(candidates: List<Manga>, query: String = ""): Manga? {
        val filtered = if (query.isBlank()) candidates else candidates
            .sortedByDescending { fuzzyScore(query, it) }
            .take(64)
        return filtered.randomOrNull(Random.Default)
    }

    fun personalTags(context: Context, mangaId: Long): Set<String> {
        val encoded = context.getSharedPreferences(STORE, Context.MODE_PRIVATE)
            .getString(PERSONAL_TAG_KEY, "").orEmpty()
        return encoded.split('|').asSequence()
            .mapNotNull { row ->
                val parts = row.split('=', limit = 2)
                if (parts.size == 2 && parts[0].toLongOrNull() == mangaId) parts[1]
                    .split(',').map(::normalize).filter(String::isNotBlank).toSet()
                else null
            }
            .firstOrNull()
            .orEmpty()
    }

    fun setPersonalTags(context: Context, mangaId: Long, tags: Set<String>) {
        val prefs = context.getSharedPreferences(STORE, Context.MODE_PRIVATE)
        val rows = prefs.getString(PERSONAL_TAG_KEY, "").orEmpty().split('|')
            .filter { it.isNotBlank() && !it.startsWith("$mangaId=") }
            .toMutableList()
        if (tags.isNotEmpty()) rows += "$mangaId=${tags.map(::normalize).filter(String::isNotBlank).distinct().take(MAX_STORED_TAGS).joinToString(",")}"
        prefs.edit().putString(PERSONAL_TAG_KEY, rows.takeLast(MAX_STORED_TAGS).joinToString("|")).apply()
    }

    fun bookmarks(context: Context, mangaId: Long): List<PageBookmark> =
        context.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString(BOOKMARK_KEY, "").orEmpty()
            .split('|').asSequence().mapNotNull(::decodeBookmark)
            .filter { it.mangaId == mangaId }.take(MAX_BOOKMARKS).toList()

    fun toggleBookmark(context: Context, bookmark: PageBookmark): Boolean {
        val prefs = context.getSharedPreferences(STORE, Context.MODE_PRIVATE)
        val current = prefs.getString(BOOKMARK_KEY, "").orEmpty().split('|')
            .filter(String::isNotBlank).mapNotNull(::decodeBookmark).toMutableList()
        val removed = current.removeAll { it.mangaId == bookmark.mangaId && it.chapterId == bookmark.chapterId && it.page == bookmark.page }
        if (!removed) current += bookmark
        prefs.edit().putString(BOOKMARK_KEY, current.takeLast(MAX_BOOKMARKS).joinToString("|", transform = ::encodeBookmark)).apply()
        return !removed
    }

    fun markReading(context: Context, day: String, pages: Int = 1) {
        val prefs = context.getSharedPreferences(STORE, Context.MODE_PRIVATE)
        val rows = prefs.getString(HEATMAP_KEY, "").orEmpty().split('|')
            .filter(String::isNotBlank).associate { row ->
                val parts = row.split('=', limit = 2)
                parts[0] to (parts.getOrNull(1)?.toIntOrNull() ?: 0)
            }.toMutableMap()
        rows[day] = (rows[day] ?: 0) + pages.coerceAtLeast(1)
        prefs.edit().putString(HEATMAP_KEY, rows.entries.takeLast(370).joinToString("|") { "${it.key}=${it.value}" }).apply()
    }

    fun heatmap(context: Context): Map<String, Int> =
        context.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString(HEATMAP_KEY, "").orEmpty()
            .split('|').asSequence().filter(String::isNotBlank).mapNotNull { row ->
                val parts = row.split('=', limit = 2)
                parts.getOrNull(0)?.let { it to (parts.getOrNull(1)?.toIntOrNull() ?: 0) }
            }.toMap()

    fun rememberSeen(context: Context, ids: Collection<Long>) {
        val prefs = context.getSharedPreferences(STORE, Context.MODE_PRIVATE)
        val existing = prefs.getString(SEEN_KEY, "").orEmpty().split(',').filter(String::isNotBlank)
        val merged = (existing + ids.map(Long::toString)).distinct().takeLast(MAX_STORED_IDS)
        prefs.edit().putString(SEEN_KEY, merged.joinToString(",")).apply()
    }

    fun seenIds(context: Context): Set<Long> =
        context.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString(SEEN_KEY, "").orEmpty()
            .split(',').mapNotNull(String::toLongOrNull).toSet()

    fun applyStealthWindow(window: Window, enabled: Boolean) {
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun encodeBookmark(bookmark: PageBookmark): String =
        "${bookmark.mangaId},${bookmark.chapterId},${bookmark.page},${bookmark.note.replace(',', ' ')}"

    private fun decodeBookmark(value: String): PageBookmark? {
        val parts = value.split(',', limit = 4)
        if (parts.size < 3) return null
        return PageBookmark(
            mangaId = parts[0].toLongOrNull() ?: return null,
            chapterId = parts[1].toLongOrNull() ?: return null,
            page = parts[2].toIntOrNull() ?: return null,
            note = parts.getOrNull(3).orEmpty(),
        )
    }

    private fun levenshtein(left: String, right: String): Int {
        if (left == right) return 0
        if (left.isEmpty()) return right.length
        if (right.isEmpty()) return left.length
        var previous = IntArray(right.length + 1) { it }
        for (i in left.indices) {
            val current = IntArray(right.length + 1)
            current[0] = i + 1
            for (j in right.indices) {
                current[j + 1] = min(
                    min(current[j] + 1, previous[j + 1] + 1),
                    previous[j] + if (left[i] == right[j]) 0 else 1,
                )
            }
            previous = current
        }
        return previous[right.length]
    }
}
