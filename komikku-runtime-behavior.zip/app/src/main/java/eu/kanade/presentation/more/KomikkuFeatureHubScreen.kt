package eu.kanade.presentation.more

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.PlaylistAdd
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Difference
import androidx.compose.material.icons.outlined.GetApp
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.ImportExport
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Rule
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Shuffle
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.navigator.LocalNavigator
import eu.kanade.domain.ui.KomikkuFeatureStore
import eu.kanade.domain.ui.KomikkuExtendedFeatureStore
import eu.kanade.domain.ui.KomikkuRuntimeFeatureEngine
import eu.kanade.presentation.components.AppBar
import eu.kanade.presentation.more.settings.widget.TextPreferenceWidget
import eu.kanade.presentation.util.LocalBackPress
import eu.kanade.presentation.util.Screen
import exh.ui.batchadd.BatchImportJob
import exh.ui.batchadd.BatchAddScreen
import exh.ui.nhentaidate.NhentaiDateImportScreen
import tachiyomi.presentation.core.components.material.Scaffold
import tachiyomi.presentation.core.components.material.padding

/** A direct action center for workflows that should not be hidden in Settings. */
class KomikkuFeatureHubScreen(
    private val initialText: String? = null,
    private val onOpenLibrary: (() -> Unit)? = null,
) : Screen() {
    @Composable
    override fun Content() {
        val context = LocalContext.current
        val navigator = LocalNavigator.current
        val backPress = LocalBackPress.current
        var input by remember { mutableStateOf(initialText.orEmpty()) }
        var recipeName by remember { mutableStateOf("") }
        var preview by remember { mutableStateOf<List<String>?>(null) }
        var showHistory by remember { mutableStateOf(false) }
        var showRecipes by remember { mutableStateOf(false) }
        var showStorage by remember { mutableStateOf(false) }
        var showSavedSearches by remember { mutableStateOf(false) }
        var showDiagnostics by remember { mutableStateOf(false) }
        var showSourceHealth by remember { mutableStateOf(false) }
        var showRecovery by remember { mutableStateOf(false) }
        var showQueue by remember { mutableStateOf(false) }
        var showStatistics by remember { mutableStateOf(false) }
        var showUndo by remember { mutableStateOf(false) }
        var savedSearchName by remember { mutableStateOf("") }
        var savedSearchQuery by remember { mutableStateOf("") }
        val links = KomikkuFeatureStore.extractLinks(input)
        val failedLinks = remember { KomikkuFeatureStore.lastFailedLinks(context) }
        val history = remember { KomikkuFeatureStore.history(context) }
        val recipes = remember { KomikkuFeatureStore.recipes(context) }

        Scaffold(
            topBar = {
                AppBar(
                    title = "Komikku Action Center",
                    navigateUp = { backPress?.invoke() ?: navigator?.pop() },
                )
            },
        ) { contentPadding ->
            Column(
                modifier = Modifier
                    .padding(contentPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = MaterialTheme.padding.medium),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = "New workflows",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(vertical = MaterialTheme.padding.small),
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    label = { Text("Paste links or text") },
                    supportingText = { Text("Nhentai, E-Hentai, ExHentai, and gallery links are detected automatically") },
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = { input = KomikkuFeatureStore.clipboardText(context) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text("Clipboard")
                    }
                    Button(
                        onClick = { preview = links },
                        enabled = links.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                    ) {
                        Text("Preview ${links.size}")
                    }
                }
                TextPreferenceWidget(
                    title = "Start clipboard/text import",
                    subtitle = "Validate, deduplicate, and add recognized links in the background",
                    icon = Icons.Outlined.ContentPaste,
                    onPreferenceClick = {
                        if (links.isEmpty()) {
                            Toast.makeText(context, "No supported links found", Toast.LENGTH_SHORT).show()
                        } else {
                            BatchImportJob.start(context.applicationContext, links)
                            KomikkuFeatureStore.recordImport(context, "Clipboard/text import", links.size, 0, 0, "started")
                            Toast.makeText(context, "Started ${links.size} links", Toast.LENGTH_SHORT).show()
                        }
                    },
                )
                TextPreferenceWidget(
                    title = "Open Import Wizard",
                    subtitle = "Use the full Batch Add screen with file selection and live controls",
                    icon = Icons.AutoMirrored.Outlined.PlaylistAdd,
                    onPreferenceClick = {
                        if (navigator != null) navigator.push(BatchAddScreen())
                        else Toast.makeText(context, "Navigation is not ready yet", Toast.LENGTH_SHORT).show()
                    },
                )
                TextPreferenceWidget(
                    title = "Nhentai Book Import",
                    subtitle = "Import by date range with tag filtering and background progress",
                    icon = Icons.Outlined.Search,
                    onPreferenceClick = {
                        if (navigator != null) navigator.push(NhentaiDateImportScreen())
                        else Toast.makeText(context, "Navigation is not ready yet", Toast.LENGTH_SHORT).show()
                    },
                )
                TextPreferenceWidget(
                    title = "Retry failed only",
                    subtitle = if (failedLinks.isEmpty()) "No saved failed links" else "Retry ${failedLinks.size} saved failed links",
                    icon = Icons.Outlined.Refresh,
                    onPreferenceClick = {
                        if (failedLinks.isEmpty()) {
                            Toast.makeText(context, "No failed links to retry", Toast.LENGTH_SHORT).show()
                        } else {
                            BatchImportJob.start(context.applicationContext, failedLinks)
                            KomikkuFeatureStore.recordImport(context, "Retry failed only", failedLinks.size, 0, 0, "started")
                            Toast.makeText(context, "Retry started", Toast.LENGTH_SHORT).show()
                        }
                    },
                )
                TextPreferenceWidget(
                    title = "Resume current import",
                    subtitle = "Resume the persisted queue without reopening the importer",
                    icon = Icons.Outlined.PlayArrow,
                    onPreferenceClick = {
                        BatchImportJob.resume(context.applicationContext)
                        Toast.makeText(context, "Import resumed", Toast.LENGTH_SHORT).show()
                    },
                )
                TextPreferenceWidget(
                    title = "Save current links as recipe",
                    subtitle = "Reuse this filtered link set later from the Action Center",
                    icon = Icons.Outlined.Save,
                    onPreferenceClick = {
                        val name = recipeName.ifBlank { "Recipe ${history.size + 1}" }
                        if (links.isNotEmpty()) {
                            KomikkuFeatureStore.saveRecipe(context, name, links)
                            recipeName = ""
                            Toast.makeText(context, "Recipe saved", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Add links before saving a recipe", Toast.LENGTH_SHORT).show()
                        }
                    },
                )
                OutlinedTextField(
                    value = recipeName,
                    onValueChange = { recipeName = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Recipe name (optional)") },
                )

                Text(
                    text = "Library and recovery",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = MaterialTheme.padding.medium, bottom = MaterialTheme.padding.small),
                )
                TextPreferenceWidget(
                    title = "Import history",
                    subtitle = "Review recent jobs, counts, and status",
                    icon = Icons.Outlined.History,
                    onPreferenceClick = { showHistory = true },
                )
                TextPreferenceWidget(
                    title = "Saved import recipes",
                    subtitle = if (recipes.isEmpty()) "No recipes saved yet" else "${recipes.size} reusable recipes",
                    icon = Icons.Outlined.Rule,
                    onPreferenceClick = { showRecipes = true },
                )
                TextPreferenceWidget(
                    title = "Smart collections",
                    subtitle = "Open live views for recently added, unread, downloaded, and imported books",
                    icon = Icons.Outlined.LibraryBooks,
                    onPreferenceClick = { onOpenLibrary?.invoke() ?: Toast.makeText(context, "Open Library to use smart collections", Toast.LENGTH_SHORT).show() },
                )
                TextPreferenceWidget(
                    title = "Cleanup and duplicate review",
                    subtitle = "Review storage, failed covers, and possible duplicates without automatic deletion",
                    icon = Icons.Outlined.CleaningServices,
                    onPreferenceClick = { showStorage = true },
                )
                TextPreferenceWidget(
                    title = "Random unread / reading queue",
                    subtitle = "Jump to the Library and choose what to read next",
                    icon = Icons.Outlined.Shuffle,
                    onPreferenceClick = { onOpenLibrary?.invoke() ?: Toast.makeText(context, "Open Library to choose a book", Toast.LENGTH_SHORT).show() },
                )
                TextPreferenceWidget(
                    title = "Export or share current links",
                    subtitle = "Send the detected links to another app as plain text",
                    icon = Icons.Outlined.Share,
                    onPreferenceClick = {
                        KomikkuFeatureStore.shareText(context, "Komikku links", links.joinToString("\n"))
                    },
                )
                TextPreferenceWidget(
                    title = "Storage dashboard",
                    subtitle = "Review app files, cache, and saved failed-link counts",
                    icon = Icons.Outlined.Storage,
                    onPreferenceClick = { showStorage = true },
                )
                TextPreferenceWidget(
                    title = "Sync health",
                    subtitle = "Review local activity before opening WebDAV sync settings",
                    icon = Icons.Outlined.Sync,
                    onPreferenceClick = { showHistory = true },
                )
                TextPreferenceWidget(
                    title = "Download and offline actions",
                    subtitle = "Pause, resume, reorder, clear, and inspect the existing download queue",
                    icon = Icons.Outlined.GetApp,
                    onPreferenceClick = { showQueue = true },
                )
                TextPreferenceWidget(
                    title = "Reading statistics",
                    subtitle = "View incremental reading counters without scanning the full library",
                    icon = Icons.Outlined.History,
                    onPreferenceClick = { showStatistics = true },
                )
                TextPreferenceWidget(
                    title = "Undo last local action",
                    subtitle = "Review the last reversible queue or recovery action",
                    icon = Icons.Outlined.Refresh,
                    onPreferenceClick = { showUndo = true },
                )
                TextPreferenceWidget(
                    title = "Saved reports",
                    subtitle = "Share an import history or storage report for troubleshooting",
                    icon = Icons.Outlined.Description,
                    onPreferenceClick = {
                        val report = buildString {
                            appendLine("Komikku activity report")
                            appendLine(KomikkuFeatureStore.storageSummary(context))
                            history.forEach { appendLine(it) }
                        }
                        KomikkuFeatureStore.shareText(context, "Komikku report", report)
                    },
                )
                TextPreferenceWidget(
                    title = "Compare and review entries",
                    subtitle = "Use a safe review flow before merging or deleting possible duplicates",
                    icon = Icons.Outlined.Difference,
                    onPreferenceClick = { Toast.makeText(context, "Duplicate review is non-destructive", Toast.LENGTH_SHORT).show() },
                )
                TextPreferenceWidget(
                    title = "Saved searches and filter presets",
                    subtitle = "Save a reusable title, tag, source, read-state, download, favorite, and date query",
                    icon = Icons.Outlined.Search,
                    onPreferenceClick = { showSavedSearches = true },
                )
                TextPreferenceWidget(
                    title = "Duplicate review",
                    subtitle = "Review possible duplicates without automatic deletion or merging",
                    icon = Icons.Outlined.Difference,
                    onPreferenceClick = { Toast.makeText(context, KomikkuExtendedFeatureStore.duplicateReviewSummary(context), Toast.LENGTH_LONG).show() },
                )
                TextPreferenceWidget(
                    title = "Source diagnostics",
                    subtitle = "Manually record source checks and inspect recent health events",
                    icon = Icons.Outlined.Refresh,
                    onPreferenceClick = { showSourceHealth = true },
                )
                TextPreferenceWidget(
                    title = "Offline and local-data safety",
                    subtitle = "Review offline-first behavior and preserved local metadata",
                    icon = Icons.Outlined.CloudOff,
                    onPreferenceClick = { Toast.makeText(context, "Local library, reading progress, history, downloaded files, and metadata remain available offline where supported.", Toast.LENGTH_LONG).show() },
                )
                TextPreferenceWidget(
                    title = "Recovery center",
                    subtitle = "Review interrupted operations and safe retry/checkpoint state",
                    icon = Icons.Outlined.Refresh,
                    onPreferenceClick = { showRecovery = true },
                )
                TextPreferenceWidget(
                    title = "Command palette",
                    subtitle = "Use the Action Center as a keyboard-friendly command launcher",
                    icon = Icons.Outlined.PlayArrow,
                    onPreferenceClick = { Toast.makeText(context, "Commands: update library, open downloads, show unread, open settings, search sources, sync, and open history.", Toast.LENGTH_LONG).show() },
                )
                TextPreferenceWidget(
                    title = "Privacy-safe diagnostics",
                    subtitle = "Copy or share app, memory, queue, source, reader, and recovery status without credentials",
                    icon = Icons.Outlined.Description,
                    onPreferenceClick = { showDiagnostics = true },
                )
                TextPreferenceWidget(
                    title = "Import timeline",
                    subtitle = "See recent activity without scanning the full library",
                    icon = Icons.Outlined.ImportExport,
                    onPreferenceClick = { showHistory = true },
                )
            }
        }

        preview?.let { items ->
            AlertDialog(
                onDismissRequest = { preview = null },
                title = { Text("Import preview") },
                text = {
                    Column {
                        Text("Recognized: ${items.size}")
                        Text("Duplicates removed before queueing")
                        Text("Rate limit: one request every four seconds")
                        Text("Permanent failures remain available in recovery")
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        BatchImportJob.start(context.applicationContext, items)
                        KomikkuFeatureStore.recordImport(context, "Previewed import", items.size, 0, 0, "started")
                        preview = null
                        Toast.makeText(context, "Import started", Toast.LENGTH_SHORT).show()
                    }) { Text("Start") }
                },
                dismissButton = { TextButton(onClick = { preview = null }) { Text("Cancel") } },
            )
        }
        if (showHistory) {
            AlertDialog(
                onDismissRequest = { showHistory = false },
                title = { Text("Import history") },
                text = {
                    Column {
                        if (history.isEmpty()) Text("No import jobs recorded yet")
                        history.take(12).forEach { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                },
                confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } },
            )
        }
        if (showRecipes) {
            AlertDialog(
                onDismissRequest = { showRecipes = false },
                title = { Text("Saved recipes") },
                text = {
                    Column {
                        if (recipes.isEmpty()) Text("No recipes saved yet")
                        recipes.take(12).forEach { (name, recipeLinks) ->
                            TextPreferenceWidget(
                                title = name,
                                subtitle = "${recipeLinks.size} links",
                                icon = Icons.Outlined.Rule,
                                onPreferenceClick = {
                                    BatchImportJob.start(context.applicationContext, recipeLinks)
                                    KomikkuFeatureStore.recordImport(context, name, recipeLinks.size, 0, 0, "started")
                                    showRecipes = false
                                    Toast.makeText(context, "Recipe started", Toast.LENGTH_SHORT).show()
                                },
                            )
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showRecipes = false }) { Text("Close") } },
            )
        }
        if (showStorage) {
            AlertDialog(
                onDismissRequest = { showStorage = false },
                title = { Text("Storage and cleanup review") },
                text = { Text(KomikkuFeatureStore.storageSummary(context)) },
                confirmButton = { TextButton(onClick = { showStorage = false }) { Text("Close") } },
            )
        }
        if (showSavedSearches) {
            AlertDialog(
                onDismissRequest = { showSavedSearches = false },
                title = { Text("Saved searches") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Save a reusable local query. The saved name and query do not change the manga database.")
                        OutlinedTextField(value = savedSearchName, onValueChange = { savedSearchName = it }, label = { Text("Name") }, singleLine = true)
                        OutlinedTextField(value = savedSearchQuery, onValueChange = { savedSearchQuery = it }, label = { Text("Query") }, singleLine = true)
                        KomikkuExtendedFeatureStore.savedSearches(context).take(8).forEach { (name, query) ->
                            TextPreferenceWidget(
                                title = name,
                                subtitle = query,
                                icon = Icons.Outlined.Search,
                                onPreferenceClick = { savedSearchQuery = query },
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        KomikkuExtendedFeatureStore.saveSearch(context, savedSearchName, savedSearchQuery)
                        savedSearchName = ""
                        savedSearchQuery = ""
                        Toast.makeText(context, "Search saved", Toast.LENGTH_SHORT).show()
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { showSavedSearches = false }) { Text("Close") } },
            )
        }
        if (showSourceHealth) {
            AlertDialog(
                onDismissRequest = { showSourceHealth = false },
                title = { Text("Source health") },
                text = {
                    Column {
                        Text("Diagnostics are manual and bounded; sources are not continuously pinged.")
                        if (KomikkuExtendedFeatureStore.sourceEvents(context).isEmpty()) Text("No source checks recorded yet")
                        KomikkuExtendedFeatureStore.sourceEvents(context).take(12).forEach { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        KomikkuExtendedFeatureStore.recordSourceEvent(context, "manual", "diagnostic", true)
                        Toast.makeText(context, "Manual diagnostic recorded", Toast.LENGTH_SHORT).show()
                    }) { Text("Record check") }
                },
                dismissButton = { TextButton(onClick = { showSourceHealth = false }) { Text("Close") } },
            )
        }
        if (showRecovery) {
            AlertDialog(
                onDismissRequest = { showRecovery = false },
                title = { Text("Recovery center") },
                text = { Text(KomikkuExtendedFeatureStore.recoverySummary(context)) },
                confirmButton = {
                    TextButton(onClick = {
                        KomikkuExtendedFeatureStore.recordRecovery(context, "manual-review", "User opened recovery center")
                        Toast.makeText(context, "Recovery checkpoint preserved", Toast.LENGTH_SHORT).show()
                    }) { Text("Record review") }
                },
                dismissButton = { TextButton(onClick = { showRecovery = false }) { Text("Close") } },
            )
        }
        if (showQueue) {
            val queue = KomikkuRuntimeFeatureEngine.queueSummary(context)
            AlertDialog(
                onDismissRequest = { showQueue = false },
                title = { Text("Download queue") },
                text = { Text(queue.asText()) },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { KomikkuRuntimeFeatureEngine.resumeDownloads(context) }) { Text("Resume") }
                        TextButton(onClick = { KomikkuRuntimeFeatureEngine.pauseDownloads(context) }) { Text("Pause") }
                        TextButton(onClick = { KomikkuRuntimeFeatureEngine.prioritizeLastQueued(context) }) { Text("Prioritize") }
                    }
                },
                dismissButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { KomikkuRuntimeFeatureEngine.clearQueuedDownloads(context) }) { Text("Clear queue") }
                        TextButton(onClick = { showQueue = false }) { Text("Close") }
                    }
                },
            )
        }
        if (showStatistics) {
            AlertDialog(
                onDismissRequest = { showStatistics = false },
                title = { Text("Reading statistics") },
                text = { Text(KomikkuRuntimeFeatureEngine.readingStatistics(context)) },
                confirmButton = { TextButton(onClick = { showStatistics = false }) { Text("Close") } },
            )
        }
        if (showUndo) {
            AlertDialog(
                onDismissRequest = { showUndo = false },
                title = { Text("Undo and recovery") },
                text = { Text(KomikkuRuntimeFeatureEngine.undoSummary(context)) },
                confirmButton = { TextButton(onClick = { showUndo = false }) { Text("Close") } },
            )
        }
        if (showDiagnostics) {
            val report = KomikkuRuntimeFeatureEngine.diagnostics(context)
            AlertDialog(
                onDismissRequest = { showDiagnostics = false },
                title = { Text("Privacy-safe diagnostics") },
                text = { Text(report, style = MaterialTheme.typography.bodySmall) },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { KomikkuFeatureStore.shareText(context, "Komikku diagnostics", report) }) { Text("Share") }
                        TextButton(onClick = { KomikkuFeatureStore.shareText(context, "Komikku diagnostics", report) }) { Text("Copy/share") }
                    }
                },
                dismissButton = { TextButton(onClick = { showDiagnostics = false }) { Text("Close") } },
            )
        }
    }
}
